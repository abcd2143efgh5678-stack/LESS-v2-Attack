rm -f CMakeCache.txt
rm -f cmake_install.cmake
rm -rf CMakeFiles
rm -rf bin
