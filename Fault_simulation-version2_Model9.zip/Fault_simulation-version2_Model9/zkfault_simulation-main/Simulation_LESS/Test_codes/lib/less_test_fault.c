#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fq_arith.h"
#include "monomial_mat.h"
#include "timing_and_stat.h"
#include "codes.h"
#include "LESS.h"
#include "rng.h"
#include "api.h"

#define GRN "\e[0;32m"
#define WHT "\e[0;37m"

#ifdef N_pad
#define NN N_pad
#else
#define NN N
#endif

#define CASE 1
#define NUM_TEST_ITERATIONS 1
#define PROB 0.05f

int sample_binom_p(){
    unsigned long M = 1<<20;
    unsigned long MAX = (unsigned long)(M/PROB);
    unsigned long p;
    randombytes((unsigned char*)&p, 8);
    p = p%MAX;
    if(p < M)
        return 1;
    else
        return 0;
}

/* Exhaustive testing of inverses mod Q */
void inverse_mod_tester(){
    uint32_t value[Q-1];
    uint32_t inverse[Q-1];
    for(uint32_t i=1; i <= Q-1; i++){
        value[i-1] = i;
        inverse[i-1] = fq_inv(i);
    }
    int all_ok = 1;
    for(uint32_t i=1; i <= Q-1; i++){
        if((value[i-1]*inverse[i-1]) % Q !=1){
           printf("%u*%u=%u\n",
                  value[i-1],
                  inverse[i-1],
                  (value[i-1]*inverse[i-1])%Q);
           all_ok = 0;
        }
    }
    if (all_ok){
        puts("All inverses on F_q ok");
    }
}


/* Test monomial matrix multiplication and inversion testing if
 * M*M^-1 = I, where I is a random monomial matrix */
void monomial_tester(){
    monomial_t mat1, mat2, id,idcheck;
    //monomial_mat_id(&idcheck);
    //monomial_mat_rnd(&mat1);
    //monomial_mat_inv(&mat2,&mat1);
    monomial_mat_mul(&id,&mat2,&mat1);
    if( memcmp( &id,&idcheck,sizeof(monomial_t)) !=0 ){
       //monomial_mat_pretty_print_name("M1",&mat1);
       //monomial_mat_pretty_print_name("M1^-1",&mat2);
       //monomial_mat_pretty_print_name("M1^-1 * M1",&id);
    } else {
        printf("Monomial arith test: ok\n");
    }
}



/*Generate a random full-rank G, keep multiplying G by a monomial and RREF'ing */
#define NUMBER_OF_GE_TESTS 10000
void gausselim_tester(){
    generator_mat_t G,GMul;
    uint8_t is_pivot_column[NN];

    /* randomly generate a non-singular G */
    do {
        //generator_rnd(&G);
        memset(is_pivot_column,0,sizeof(is_pivot_column));
    } while ( generator_RREF(&G,is_pivot_column) == 0);

    /* Stress-test GE by repeatedly bringing in SF GQ*/
    monomial_t mat1;
    int full_rank,rref_ok, all_ok = 1;
    for(int i=0; (i<NUMBER_OF_GE_TESTS) && all_ok; i++ ){
        //monomial_mat_rnd(&mat1);
        generator_monomial_mul(&GMul,&G,&mat1);
        memcpy(&G,&GMul,sizeof(generator_mat_t));
        memset(is_pivot_column,0,sizeof(is_pivot_column));
        full_rank = generator_RREF(&GMul,is_pivot_column);
        if(!full_rank){
            all_ok = 0;
            fprintf(stderr,"Singular Matrix (iter:%d)\n",i);
            //generator_pretty_print_name("Pre-GE",&G);
            //generator_pretty_print_name("Post-GE",&GMul);
        }

        /* check if the matrix is in reduced row echelon form i.e,
         *  - there are k pivots
         *  - each pivot appears as the first element of a row
         *  - is_pivot_column indicator array is correct
         */
        rref_ok = 1;
        for(int row_idx = 0; row_idx < K; row_idx++){
            int found_pivot_column = 0;
            while ( (GMul.values[row_idx][found_pivot_column] == 0) &&
                   (found_pivot_column < N) ){
                found_pivot_column++;
            }
            if ( (GMul.values[row_idx][found_pivot_column] != 1) ){
                fprintf(stderr,"row %d Pivot actually equal to %d\n",row_idx, GMul.values[row_idx][found_pivot_column]);
                     rref_ok = 0;
                }
            if ( (found_pivot_column >= N) ){
                fprintf(stderr,"row %d Pivot missing\n",row_idx);
                     rref_ok = 0;
                }
            if ( (is_pivot_column[found_pivot_column] != 1)){
                fprintf(stderr,"row %d indicator array mismatch\n",row_idx);
                     rref_ok = 0;
                }
        }

        if(full_rank && !rref_ok){
            fprintf(stderr,"RREF incorrect (iter:%d)\n",i);
            fprintf(stderr,"Pre-RREF\n");
            //generator_pretty_print_name("Pre-RREF",&G);
            fprintf(stderr,"is_pivot = \n [ ");
            for(int x=0;x < N ;x++){fprintf(stderr," %d ",is_pivot_column[x]); }
            fprintf(stderr,"]\n");
            fprintf(stderr,"Post-RREF\n");
            //generator_pretty_print_name("Post-RREF",&GMul);
            all_ok = 0;
        }

    }
    if(all_ok) {
        printf("GE test: ok\n");
    }
}


/* tests if G*M1*(M1^-1) = G*/
void gen_by_monom_tester(){
     generator_mat_t G = {0}, G2, Gcheck;
     uint8_t is_pivot_column[NN];
     /* randomly generate a non-singular G */
     do {
         //generator_rnd(&G);
         memset(is_pivot_column,0,sizeof(is_pivot_column));
     } while ( generator_RREF(&G,is_pivot_column) == 0);
     monomial_t mat1, mat2;
     //monomial_mat_rnd(&mat1);
     //monomial_mat_inv(&mat2,&mat1);
     generator_monomial_mul(&G2,&G,&mat1);
     generator_monomial_mul(&Gcheck,&G2,&mat2);
     if( memcmp( &Gcheck,&G,sizeof(generator_mat_t)) !=0 ){
        //generator_pretty_print_name("G",&G);
        //generator_pretty_print_name("G*Q",&G2);
        //generator_pretty_print_name("G*Q*Q^-1",&Gcheck);
     } else {
         printf("Generator-monomial multiplication: ok\n");
     }
}


/* draw random full rank G and pack it */
/* compute mu = Q_a^-1 Q_b */
/* compute G2 = G Q_a */
/* compute G3 = G Q_b */
/* compute Gcheck = G2 mu */

void rref_gen_by_monom_tester(){
     generator_mat_t G, G2, G3, Gcheck;

     monomial_t Q_a,Q_a_inv,Q_b,mu,Qcheck;
     //monomial_mat_rnd(&Q_a);
     //monomial_mat_inv(&Q_a_inv,&Q_a);
     //monomial_mat_rnd(&Q_b);

     uint8_t is_pivot_column[NN];
     /* randomly generate a non-singular G */
     do {
         //generator_rnd(&G);
         memset(is_pivot_column,0,sizeof(is_pivot_column));
     } while ( generator_RREF(&G,is_pivot_column) == 0);

     generator_monomial_mul(&G2,&G,&Q_a);
     if (generator_RREF(&G2,is_pivot_column) != 1){
         printf("G2=G Q_a: singular\n");

     };
     generator_monomial_mul(&G3,&G,&Q_b);
     if (generator_RREF(&G3,is_pivot_column) != 1){
         printf("G3=G Q_b: singular\n");

     };
     monomial_mat_mul(&mu,&Q_a_inv,&Q_b);


    monomial_mat_mul(&Qcheck,&Q_a,&mu);
    if( memcmp( &Q_b,&Qcheck,sizeof(monomial_t)) !=0 ){
        //monomial_mat_pretty_print_name("mu",&mu);
        //monomial_mat_pretty_print_name("Q_a",&Q_a);
        //monomial_mat_pretty_print_name("Qcheck",&Qcheck);
        //monomial_mat_pretty_print_name("Q_b",&Q_b);
        fprintf(stderr,"Q_a mu != Q_b\n");
    }


     generator_monomial_mul(&Gcheck,&G2,&mu);
     generator_RREF(&Gcheck,is_pivot_column);
     if (generator_RREF(&Gcheck,is_pivot_column) != 1){
         printf("Gcheck=G2 mu: singular\n");

     };

     if( memcmp( &Gcheck,&G3,sizeof(generator_mat_t)) !=0 ){
         printf("SF Generator-monomial multiplication: not ok\n");
        //generator_pretty_print_name("G",&G);
        //generator_pretty_print_name("G2",&G2);
        //generator_pretty_print_name("G3",&G3);
        //generator_pretty_print_name("Gcheck",&Gcheck);
        //monomial_mat_print_exp_name("Q_a",&Q_a);
        //monomial_mat_print_exp_name("Q_a_inv",&Q_a_inv);
        //monomial_mat_print_exp_name("Q_b",&Q_b);
        //monomial_mat_print_exp_name("mu",&mu);
        //monomial_mat_print_exp_name("Qcheck",&Qcheck);
     } else {
         printf("SF Generator-monomial multiplication: ok\n");
     }
}

void rref_gen_compress_tester(){
     generator_mat_t G = {0}, Gcheck;
     rref_generator_mat_t SF_G;
     uint8_t is_pivot_column[NN];

     /* randomly generate a non-singular G */
     do {
         //generator_rnd(&G);
         memset(is_pivot_column,0,sizeof(is_pivot_column));
     } while ( generator_RREF(&G,is_pivot_column) == 0);

     memcpy(&Gcheck,&G, sizeof(G));
     generator_rref_compact(&SF_G,&G,is_pivot_column);
     //generator_rnd(&G); /* fill with garbage to elicit faults */
     generator_rref_expand(&G,&SF_G);

    if( memcmp( &Gcheck,&G,sizeof(generator_mat_t)) !=0 ){
        printf("Generator SF compression: ko\n");
       fprintf(stderr," Comp-decomp\n");
       //generator_pretty_print_name("G",&G);
       fprintf(stderr,"is_pivot = \n [ ");
       for(int x=0;x < N ;x++){fprintf(stderr," %d ",is_pivot_column[x]); }
       fprintf(stderr,"]\n");

       //generator_rref_pretty_print_name("RREF-G",&SF_G);

       fprintf(stderr," Reference\n");
       //generator_pretty_print_name("Gcheck",&Gcheck);
    } else {
        printf("Generator SF compression: ok\n");
    }
}

/*void mono_is_compress_tester(){
    monomial_action_IS_t Q_a, Qcheck;
    uint8_t compressed [MONO_ACTION_PACKEDBYTES];

    monomial_t mono_rnd;
    //monomial_mat_rnd(&mono_rnd);

    // Create random q
    for (int i = 0; i < K; i++) {
        Q_a.coefficients[i] = mono_rnd.coefficients[i];
        Q_a.permutation[i] = mono_rnd.permutation[i];
    }

     compress_monom_action(compressed,&Q_a);
     expand_to_monom_action(&Qcheck,compressed);

    if( memcmp( &Qcheck,&Q_a,sizeof(monomial_action_IS_t)) !=0 ){
        printf("Monomial Action compression: ko\n");

       fprintf(stderr,"perm = [");
       for(int i = 0; i < K-1; i++) {
          fprintf(stderr,"%03u, ",Q_a.permutation[i]);
       }
       fprintf(stderr,"%03u ]\n",Q_a.permutation[K-1]);
       fprintf(stderr,"coeffs = [");
       for(int i = 0; i < K-1; i++) {
          fprintf(stderr,"%03u, ",Q_a.coefficients[i]);
       }
       fprintf(stderr,"%03u ]\n",Q_a.coefficients[K-1]);

       fprintf(stderr,"\n\n\n");
       fprintf(stderr,"perm = [");
       for(int i = 0; i < K-1; i++
        ) {
          fprintf(stderr,"%03u, ",Qcheck.permutation[i]);
       }
       fprintf(stderr,"%03u ]\n",Qcheck.permutation[K-1]);
       fprintf(stderr,"coeffs = [");
       for(int i = 0; i < K-1; i++) {
          fprintf(stderr,"%03u, ",Qcheck.coefficients[i]);
       }
       fprintf(stderr,"%03u ]\n",Qcheck.coefficients[K-1]);

    } else {
        printf("Monomial Action compression: ok\n");
    }

}*/


void rref_gen_byte_compress_tester(){
     generator_mat_t G = {0}, Gcheck;
     uint8_t G_compressed [RREF_MAT_PACKEDBYTES];
     uint8_t is_pivot_column[NN];

     /* randomly generate a non-singular G */
     do {
         //generator_rnd(&G);
         memset(is_pivot_column,0,sizeof(is_pivot_column));
     } while ( generator_RREF(&G,is_pivot_column) == 0);

     memcpy(&Gcheck,&G, sizeof(G));
     compress_rref(G_compressed,&G,is_pivot_column);
     //generator_rnd(&G); /* fill with garbage to elicit faults */
     //expand_to_rref(&G,G_compressed);

    if( memcmp( &Gcheck,&G,sizeof(generator_mat_t)) !=0 ){
        printf("Generator SF byte compression: ko\n");
       fprintf(stderr," Comp-decomp\n");
       //generator_pretty_print_name("G",&G);

       fprintf(stderr,"is_pivot = \n [ ");
       for(int x=0;x < N ;x++){fprintf(stderr," %d ",is_pivot_column[x]); }
       fprintf(stderr,"]\n");

       fprintf(stderr," \n\n\n\n\n\n\n\n\nReference\n");
       //generator_pretty_print_name("Gcheck",&Gcheck);
    } else {
        printf("Generator SF compression: ok\n");
    }
}

/*void info(){
    fprintf(stderr,"Code parameters: n= %d, k= %d, q=%d\n", N,K,Q);
    fprintf(stderr,"num. keypairs = %d\n",NUM_KEYPAIRS);
    fprintf(stderr,"Fixed weight challenge vector: %d rounds, weight %d \n",T,W);
    fprintf(stderr,"Private key: %luB\n", sizeof(prikey_t));
    fprintf(stderr,"Public key %luB\n", sizeof(pubkey_t));
    fprintf(stderr,"Signature: %luB\n", sizeof(sig_t));

}*/

/* returns 1 if the test is successful, 0 otherwise */
int LESS_sign_verify_test(){
    pubkey_t pk;
    prikey_t sk;
    sign_t signature;
    char message[8] = "Signme!";
    LESS_keygen(&sk,&pk);
    LESS_sign(&sk,message,8,&signature);
    int is_signature_ok;
    is_signature_ok = LESS_verify(&pk,message,8,&signature);
    // fprintf(stderr,"Keygen-Sign-Verify: %s", is_signature_ok == 1 ? "functional\n": "not functional\n" );
    return is_signature_ok;
}


// *** new additional functions ****//

#define TO_PUBLISH 0
#define NOT_TO_PUBLISH 1
#define LEFT_CHILD(i) (2*i+1)
#define RIGHT_CHILD(i) (2*i+2)
#define PARENT(i) ((i-1)/2)
#define SIBLING(i) ( ((i)%2) ? i+1 : i-1 )
#define IS_LEFT_SIBLING(i) (i%2)

/*void find_partial_monomial_update2(monomial_t *Q_partial, monomial_action_IS_t *Q_in, monomial_action_IS_t *Q_out, int* IS_J){
    
    monomial_t Q_in_inv;
    
    for(int i=0; i<N; i++){
        Q_in_inv.permutation[i]=N+1;
        Q_in_inv.coefficients[i]=0;
    }
    for(int i=0; i<K; i++){
        Q_in_inv.permutation[Q_in->permutation[i]] = i;
        Q_in_inv.coefficients[Q_in->permutation[i]] = Q_in->coefficients[i];
    }
    
    for(int i=0;i<K;i++)
        IS_J[Q_in->permutation[i]] = 1;


    for(int i=0; i<N; i++){
        if(Q_in_inv.permutation[i]!=(N+1) && Q_partial->permutation[i]==(N+1)){
            
            Q_partial->permutation[i] = Q_out->permutation[Q_in_inv.permutation[i]];
            Q_partial->coefficients[i] = fq_red((FQ_DOUBLEPREC) Q_out->coefficients[Q_in_inv.permutation[i]] * fq_inv(Q_in_inv.coefficients[i]));
        }
    }

}*//*Our function*/

void find_partial_monomial_update(monomial_t *Q_partial, monomial_action_IS_t *Q_in, monomial_action_IS_t *Q_out){
    
    monomial_t Q_in_inv;
    
    for(int i=0; i<N; i++){
        Q_in_inv.permutation[i]=N+1;
        Q_in_inv.coefficients[i]=0;
    }
    for(int i=0; i<K; i++){
        Q_in_inv.permutation[Q_in->permutation[i]] = i;
       // Q_in_inv.coefficients[Q_in->permutation[i]] = Q_in->coefficients[i];
    }
    
    for(int i=0; i<N; i++){
        if(Q_in_inv.permutation[i]!=(N+1) && Q_partial->permutation[i]==(N+1)){
            
            Q_partial->permutation[i] = Q_out->permutation[Q_in_inv.permutation[i]];
            //Q_partial->coefficients[i] = fq_red((FQ_DOUBLEPREC) Q_out->coefficients[Q_in_inv.permutation[i]] * fq_inv(Q_in_inv.coefficients[i]));
        }
    }

}/*Our function*/

/*void partial_monomial_initialize(monomial_t *Q_partial){
   for(int i=0; i<N; i++){
        Q_partial->permutation[i]=N+1;
        Q_partial->coefficients[i]=0;
    }
}*//*Our function*/

/*void partial_monomial_transpose(monomial_t *Q_partial_transpose, monomial_t *Q_partial){
   for(int i=0; i<N; i++){
         Q_partial_transpose->permutation[i] = N+1;
         Q_partial_transpose->coefficients[i]= 0; 
      
    }
   for(int i=0; i<N; i++){
      if(Q_partial->permutation[i]!=N+1){
         Q_partial_transpose->permutation[Q_partial->permutation[i]] = i;
         Q_partial_transpose->coefficients[Q_partial->permutation[i]]= Q_partial->coefficients[i]; 
      }
    }
}*//*Our function*/

/*int update_count_mono(monomial_t *Q_partial){
   int count = 0;
   for(int i=0; i<N; i++){
      if(Q_partial->permutation[i]!=(N+1))
         count++;      
    }
   return count;
}*//*Our function*/

/*int Error_count(monomial_t *Q_partial, monomial_t *Q_transpose){
   int count = 0;
   for(int i=0; i<N; i++){
      if(Q_partial->permutation[i]!=(N+1))
         if(Q_partial->permutation[i]!=Q_transpose->permutation[i])
            return 1;      
    }
   return count;
}*/


int generate_partial_seed_tree(unsigned char
                                  seed_tree[NUM_NODES_SEED_TREE *
                                                               SEED_LENGTH_BYTES],
                                  const unsigned char root_seed[SEED_LENGTH_BYTES],
                                  const unsigned char salt[HASH_DIGEST_LENGTH])
{
   /* input buffer to the CSPRNG, contains a salt, the seed to be expanded
    * and the integer index of the node being expanded for domain separation */
   const uint32_t csprng_input_len = HASH_DIGEST_LENGTH +
                                     SEED_LENGTH_BYTES +
                                     sizeof(uint32_t);
   unsigned char csprng_input[csprng_input_len];
   SHAKE_STATE_STRUCT tree_csprng_state;

   memcpy(csprng_input, salt, HASH_DIGEST_LENGTH);

   /* Set the root seed in the tree from the received parameter */
   uint32_t k=0,count=0;
   memcpy(seed_tree+SEED_LENGTH_BYTES,root_seed,SEED_LENGTH_BYTES);
   for (uint32_t i = 1; i < NUM_LEAVES_SEED_TREE-1; ) {
      /* prepare the CSPRNG input to expand the children of node i */
      memcpy(csprng_input + HASH_DIGEST_LENGTH,
             seed_tree + i*SEED_LENGTH_BYTES,
             SEED_LENGTH_BYTES);
      *((uint32_t *)(csprng_input + HASH_DIGEST_LENGTH + SEED_LENGTH_BYTES)) = i;
      /* expand the children (stored contiguously) */
      initialize_csprng(&tree_csprng_state, csprng_input, csprng_input_len);
      csprng_randombytes(seed_tree + LEFT_CHILD(i)*SEED_LENGTH_BYTES,
                         2*SEED_LENGTH_BYTES,
                         &tree_csprng_state);
      count++;
      if(count==(1<<k)){
         k++;
         count=0;
         i=(uint32_t)((1<<(k+1))-1);
      }
      else{
         i++;
      }
   }
   return (1<<k);
} /*Generate partial ephem_seeds from the node tree[1]*//*Our function*/

/*************************************************
//                New functions
//                Updated versions
//
************************************************/
/*int compare(generator_mat_t *G, generator_mat_t *G_tilde, FQ_ELEM multiplier, int col){
    
    int i, j;
    for(i=0; i<N; i++){
        for(j=0; j<K; j++){
            FQ_ELEM tmp = fq_red((FQ_DOUBLEPREC)G_tilde->values[j][i] * (FQ_DOUBLEPREC)multiplier);
            if(tmp!=G->values[j][col])
                break;
        }
        if(j==K)
            return i;
    }
    return N+1;
}*/
/*void generator_monomial_mul_update(invertible_mat_t *res,
                            const generator_mat_t *const G,
                            const monomial_action_IS_t *const monom)
{
   for(int src_col_idx = 0; src_col_idx < K; src_col_idx++) {
      for(int row_idx = 0; row_idx < K; row_idx++) {
         res->values[row_idx][monom->permutation[src_col_idx]] =
            fq_red( (FQ_DOUBLEPREC) G->values[row_idx][src_col_idx] *
                    (FQ_DOUBLEPREC) monom->coefficients[src_col_idx] );
      }
   }
}*/

/*static inline
void swap_rows(FQ_ELEM r[N],FQ_ELEM s[N])
{
   FQ_ELEM tmp;
   for(int i=0; i<N; i++) {
      tmp = r[i];
      r[i] = s[i];
      s[i] = tmp;
   }
}*/ /* end swap_rows */

/*int matrix_inverse(invertible_mat_t *G)
{
    generator_mat_t G_tilde;
    for(int row_to_reduce = 0; row_to_reduce < K; row_to_reduce++){
        for(int col_to_reduce = 0; col_to_reduce < K; col_to_reduce++){
            G_tilde.values[row_to_reduce][col_to_reduce] = G->values[row_to_reduce][col_to_reduce];
        }
        for(int col_to_reduce = K; col_to_reduce < N; col_to_reduce++){
            G_tilde.values[row_to_reduce][col_to_reduce] = 0;
            if(col_to_reduce== row_to_reduce+K)
                G_tilde.values[row_to_reduce][col_to_reduce] = 1;
        }
    }

   for(int row_to_reduce = 0; row_to_reduce < K; row_to_reduce++) {
      int pivot_row = row_to_reduce;*/
      /*start by searching the pivot in the col = row*/
      /*int pivot_column = row_to_reduce;
      while( (pivot_column < N) &&
             (G_tilde.values[pivot_row][pivot_column] == 0) ) {

         while ( (pivot_row < K) &&
                 (G_tilde.values[pivot_row][pivot_column] == 0) ) {
            pivot_row++;
         }
         if(pivot_row >= K) {*/ /*entire column tail swept*/
            //pivot_column++; /* move to next col */
            //pivot_row = row_to_reduce; /*starting from row to red */
        /* }
      }
      if ( pivot_column >=N ) {
         return 0; *//* no pivot candidates left, report failure */
      //}
      //is_pivot_column[pivot_column] = 1; /* pivot found, mark the column*/


      /* if we found the pivot on a row which has an index > pivot_column
       * we need to swap the rows */
      /*if (row_to_reduce != pivot_row) {
         swap_rows(G_tilde.values[row_to_reduce],G_tilde.values[pivot_row]);
      }
      pivot_row = row_to_reduce;*/ /* row with pivot now in place */


      /* Compute rescaling factor */
      //FQ_DOUBLEPREC scaling_factor = fq_inv(G_tilde.values[pivot_row][pivot_column]);

      /* rescale pivot row to have pivot = 1. Values at the left of the pivot
       * are already set to zero by previous iterations */
      /*for(int i = pivot_column; i < N; i++) {
         G_tilde.values[pivot_row][i] = fq_red( (FQ_DOUBLEPREC) scaling_factor *
                                           (FQ_DOUBLEPREC) (G_tilde.values[pivot_row][i]) );
      }*/

      /* Subtract the now placed and reduced pivot rows, from the others,
       * after rescaling it */
      /*for(int row_idx = 0; row_idx < K; row_idx++) {
         if (row_idx != pivot_row) {
            FQ_DOUBLEPREC multiplier = G_tilde.values[row_idx][pivot_column];*/
            /* all elements before the pivot in the pivot row are null, no need to
             * subtract them from other rows. */
            /*for(int col_idx = 0; col_idx < N; col_idx++) {
               FQ_DOUBLEPREC tmp;
               tmp = fq_red( (FQ_DOUBLEPREC) multiplier *
                             (FQ_DOUBLEPREC) G_tilde.values[pivot_row][col_idx] );

               tmp = (FQ_DOUBLEPREC) Q + (FQ_DOUBLEPREC) G_tilde.values[row_idx][col_idx] - tmp;
               tmp = fq_red(tmp);

               G_tilde.values[row_idx][col_idx] = tmp;
            }
         }
      }
   }*/
   /*for(int row_to_reduce = 0; row_to_reduce < K; row_to_reduce++){
        for(int col_to_reduce = 0; col_to_reduce < K; col_to_reduce++){
            G->values[row_to_reduce][col_to_reduce] = G_tilde.values[row_to_reduce][K+col_to_reduce];

            if((row_to_reduce == col_to_reduce) && (G_tilde.values[row_to_reduce][col_to_reduce] != 1)) printf("\nError\n");
            if((row_to_reduce != col_to_reduce) && (G_tilde.values[row_to_reduce][col_to_reduce] != 0)) printf("\nError\n");
        }
    }


   return 1;
}*/ /* end generator_RREF */

/*void mul_invertible_generator(generator_mat_t *G_tilde, invertible_mat_t *G, generator_mat_t *result_G){
    for(int i=0; i<K; i++){
        for(int j=0; j<N; j++){
            FQ_ELEM sum = 0;
            for(int r=0; r<K; r++){
                sum=fq_red((FQ_DOUBLEPREC)sum+fq_red((FQ_DOUBLEPREC)G->values[i][r]*(FQ_DOUBLEPREC)result_G->values[r][j]));
            }
            G_tilde->values[i][j] = sum;
        }
    }
}*/

/*void mul_invertible_invertible(invertible_mat_t *res, invertible_mat_t *G_1, invertible_mat_t *G_2){
    
    for(int i=0; i<K; i++){
        for(int j=0; j<K; j++){
            FQ_ELEM sum = 0;
            for(int r=0; r<K; r++){
                sum=fq_red((FQ_DOUBLEPREC)sum + fq_red((FQ_DOUBLEPREC)G_1->values[i][r]*(FQ_DOUBLEPREC)G_2->values[r][j]));
            }
            res->values[i][j] = sum;
        }
    }
}

int inverse(generator_mat_t G, monomial_action_IS_t Q_in, invertible_mat_t S){
    invertible_mat_t result_G;
    generator_monomial_mul_update(&result_G,
                             &G,
                             &Q_in);
    generator_inverse(&result_G);
    
}*/
//int SIM_secret_key_single_fault(int *num_cols);
//int SIM_recover_full_secret_key(int *num_sign);
//int SIM_recover_full_secret_key_prob(int *num_sign);


/// End of new functions

#define failure 0
#define success 1


int main(int argc, char* argv[]){
    uint8_t seed[] ={0x83,0xC6,0x53,0x70,0x8F,0xAF,0x3E,0x5F,0x6F,0xBC,0x9D,0xFB,0xE6,0xFB,0x5E,0x83,0xE5,0x72,0xA7,0x68,0x86,0x45,0xD7,0x5D,0x2C,0x48,0x35,0xB2,0x86,0x95,0xDE,0xA4,0xBD,0x70,0x93,0x74,0x0D,0x0F,0xF4,0x32,0x37,0x35,0x4E,0xAD,0x1C,0x97,0x8B,0xC2};
    uint8_t m[] ={0xE3,0xB5,0x7B,0x20,0x83,0x52,0xA8,0x20,0xF6,0x22,0xA6,0x94,0xB7,0xC3,0xF6,0xF2,0x97,0x23,0x9E,0xF0,0xA0,0x69,0x61,0x5D,0xC6,0x64,0xC0,0x2F,0x18,0x22,0xBB,0xA4,0x8E,0x11,0xE3,0x7B,0xD9,0x74,0x9C,0x98,0xFA,0xCE,0xFF,0xFB,0x0F,0xE1,0x79,0x2A,0x38,0x6B,0xE1,0x0C,0xA7,0xB9,0x8C,0xC8,0x74,0xC6,0x8C,0x36,0xF5,0x09,0x6D,0x37,0x18,0xDC,0x93,0xE0,0x73,0x4D,0x6D,0x6F,0x91,0x3E,0x3B,0x95,0x8D,0xC1,0xFD,0x14,0x24,0x81,0x8C,0x94,0x37,0xB0,0xFD,0x59,0x72,0x8E,0xD4,0x6A,0x79,0xFB,0x52,0xC7,0x37,0xA1,0xD1,0xD2,0x6F,0x04,0xEB,0xAC,0x27,0x9A,0x7F,0xF6,0xA9,0x71,0xE2,0xB6,0x95,0x76,0xB7,0x12,0xD9,0x22,0x4E,0xA1,0x8F,0xB9,0xBF,0x4E,0x61,0x3A,0x89,0x35,0xF3,0xB3,0x6A,0x07,0x3B,0x01,0xF3,0x7B,0xDC,0x0B,0x77,0x98,0x1C,0x8F,0x28,0x04,0xE9,0x3C,0x39,0x54,0x19,0x35,0x2B,0x85,0xC8,0xA3,0x2D,0xD7,0x7D,0x41,0xDA,0x9B,0xF3,0xEC,0xB9,0x14,0x17,0x3E,0x80,0xDD,0x1F,0xC0,0x6E,0x8F,0xF5,0xBF,0x0E,0x4F,0x74,0x24,0x84,0x9A,0x15,0xEB,0x7F,0xAF,0x7D,0xE7,0x74,0x56,0xEB,0xB6,0x4D,0x10,0xDC,0x10,0xFE,0xC6,0x25,0x40,0x70,0xC7,0xDF,0x38,0x73,0x97,0x13,0x73,0x72,0xEA,0x3A,0x53,0xDF,0xDA,0x7D,0xA1,0x34,0x14,0xAF,0x2D,0xF1,0x6C,0x1E,0x38,0xC5,0xC7,0x0A,0x5F,0x5F,0x44,0xF7,0x25,0xD6,0x22,0x04,0x92,0x56,0xBB,0x15,0xDC,0x04,0xA8,0xD8,0x46,0xA1,0xA0,0xDA,0xE7,0xE7,0x65,0xA7,0xF0,0x0C,0x49,0x8F,0x1D,0x0B,0x28,0x93,0xB8,0x40,0x5B,0xE4,0xA4,0x3F,0xB7,0xE9,0x78,0x81,0x06,0x9A,0x49,0x13,0x4A,0x2A,0x84,0x71,0x84,0xB8,0x2E,0xB5,0xA6,0x90,0xD8,0x7B,0xAF,0x2F,0x57,0x96,0x19,0xEE,0x19,0xA3,0xD7,0xA7,0xC7,0xEE,0xA7,0x2D,0x6E,0x3F,0xCC,0xF0,0xA8,0x09,0x2B,0xB8,0xD3,0xC6,0xB5,0x51,0xF2,0x7E,0x63,0xE7,0x62,0xA3,0x0B,0x4A,0x4D,0xF2,0xDB,0xC4,0xD1,0x19,0x13,0x9A,0xE1,0xB1,0x35,0xD0,0x6F,0xF8,0x27,0x84,0x69,0x01,0x57,0x77,0x00,0x93,0x5E,0x00,0x11,0xB6,0x54,0x61,0xC2,0xEF,0x9A,0x7B,0x71,0xEE,0xA3,0x3C,0x8C,0xA4,0x51,0x9C,0x7B,0xCF,0xB5,0x57,0xC5,0xE1,0xD4,0x2D,0x92,0x43,0xF2,0xDC,0x34,0x05,0x7F,0x5E,0x0C,0xCB,0x9A,0x45,0x7F,0xC3,0x4D,0xCB,0x10,0xD9,0xB4,0x7F,0x6E,0xC3,0xB9,0x55,0x0D,0x3A,0xE4,0xFD,0x59,0x3D,0xFA,0x3E,0x28,0xC6,0xCC,0xA1,0xFF,0x1E,0xBC,0x9D,0x98,0xDA,0x8D,0xB8,0x69,0xF8,0xC8,0x0B,0xDB,0xF8,0xAD,0x46,0x84,0xAC,0xB6,0xA7,0x79,0xCA,0x9D,0x0A,0x10,0x6F,0x26,0xDA,0x17,0x04,0x37,0x73,0x86,0x26,0x81,0xC5,0xDD,0x2D,0xEB,0x1B,0xCA,0x2C,0xA4,0x8D,0x4F,0xBB,0x4B,0xB7,0xC1,0xF7,0x65,0xDC,0xA3,0xA1,0xD9,0x91,0xD8,0x90,0xB9,0xA8,0x75,0x1C,0xEA,0xFF,0x54,0x39,0x97,0xFA,0xE5,0xB1,0x28,0xAB,0x2E,0xF2,0x2B,0x3B,0xE9,0x44,0x99,0xDF,0xD9,0xD8,0xE7,0x8F,0xB4,0xC8,0x2C,0xA8,0xD2,0x96,0xB0,0x41,0x5E,0x84,0xCA,0x8B,0x5F,0x20,0x24,0x45,0x5B,0x5D,0xEC,0xC8,0xB4,0xCC,0xDC,0x7B,0xC4,0xEE,0x06,0xB4,0xF0,0xC6,0x6E,0x67,0x48,0xFB,0xD0,0x7E,0x3A,0x3B,0xC5,0xB4,0xB6,0x88,0x9C,0x40,0xDC,0x4A,0x97,0xAE,0x3E,0xB4,0x3C,0x39,0x14,0xDE,0xF9,0x76,0xEF,0xE3,0xBF,0xD8,0x4A,0x09,0x3B,0xD6,0x91,0x02,0xD7,0xB3,0x7C,0x89,0xB4,0x58,0xA5,0x5B,0x98,0xA1,0x97,0x4A,0x13,0xA7,0x68,0x5D,0x26,0xE9,0xD8,0x16,0xC7,0x95,0x85,0xBC,0xFC,0x10,0x42,0xC2,0xAF,0x88,0x53,0x4A,0x9F,0xE8,0xB0,0xA6,0xC8,0xC4,0x43,0x55,0xA6,0xD6,0x06,0xF9,0x02,0xDB,0x40,0xD5,0x49,0x02,0x64,0xBF,0x0F,0x35,0x2C,0x27,0x35,0x56,0x33,0xCB,0x09,0x52,0x68,0xD5,0xB8,0xBE,0xC9,0x85,0xA6,0x2D,0x84,0xB2,0x32,0x3F,0xE8,0x14,0x05,0x3F,0x05,0xDE,0xDC,0x22,0x02,0x9D,0x29,0x98,0xBD,0x0B,0xCB,0x25,0x5C,0x16,0x2C,0x4B,0xC0,0x3F,0x60,0xE3,0x58,0x0A,0xC3,0xAE,0x86,0xC3,0x78,0x50,0x11,0x0E,0x9A,0x1B,0xCB,0xD7,0x5F,0x64,0xA0,0xDD,0x60,0xB9,0x41,0xE2,0xF5,0x7D,0xA9,0xD7,0x24,0x98,0xB3,0xEA,0x83,0x24,0xEE,0xA5,0x3D,0xA3,0x89,0x55,0x85,0xED,0x29,0x42,0xB9,0x14,0x0F,0x26,0x08,0x95,0xDC,0x6A,0x11,0x31,0xA4,0xC3,0xAD,0x2B,0x64,0x02,0x8B,0xB8,0xC0,0xFD,0x67,0xE1,0xBE,0x4C,0x07,0xF8,0x08,0xB4,0x7D,0xAE,0xF3,0x06,0xFD,0x95,0x78,0x02,0x5F,0x9C,0x63,0x96,0x60,0x07,0x58,0x37,0xB2,0xC9,0x54,0x73,0xF7,0xF8,0x60,0xD6,0xEA,0x2C,0x53,0xF4,0xBA,0x67,0x7A,0x23,0x45,0xCF,0x21,0x2C,0x77,0x57,0xBB,0x94,0xF1,0xA4,0xF7,0x6D,0x4E,0x96,0x62,0x5F,0x6F,0xE0,0x51,0xB8,0x24,0x6D,0x1B,0x76,0x11,0xBF,0x6F,0xE3,0x25,0xFF,0xFF,0x85,0x14,0xD2,0xF9,0xA3,0x45,0x3F,0x0E,0x77,0xAE,0x8B,0x95,0x8A,0xB5,0xB5,0x67,0xE5,0x41,0xF1,0x56,0xC6,0xF4,0xD3,0x15,0xB4,0xC3,0xC5,0x47,0xD5,0x9B,0xBD,0x0D,0x74,0x03,0xE2,0xE6,0xA4,0x9B,0x9E,0x7D,0x3F,0xDB,0xA3,0x38,0xAD,0xA4,0x18,0x75,0xCE,0xB0,0x38,0x30,0xA8,0x46,0xA1,0xFB,0x26,0x6C,0x0F,0x12,0x28,0xAA,0xD2,0xB7,0x6A,0x2E,0x34,0x04,0x27,0x8D,0xBE,0x48,0x29,0x07,0x20,0x6F,0xA6,0x64,0x87,0xAD,0x2C,0x99,0x98,0x67,0xF8,0x70,0xC8,0xCB,0x7A,0x70,0xB8,0x34,0x37,0xE1,0x4B,0x9E,0x89,0x3B,0xF6,0xB3,0x91,0xDA,0xD7,0x5E,0x84,0x58,0x8E,0x88,0x22,0x46,0xD1,0x61,0x79,0x9A,0xDE,0xA6,0x3A,0xDF,0x1A,0xD7,0x06,0xC0,0xA3,0xB7,0x6B,0xAE,0x59,0x5D,0x84,0xB2,0x1A,0xE9,0xDA,0x30,0xBB,0xC0,0x85,0x69,0x87,0xF2,0xC2,0xC5,0x43,0xD9,0x77,0x74,0x7B,0x8C,0xBD,0x5A,0x61,0x3B,0x92,0x80,0x4E,0xCC,0x52,0x84,0xED,0x23,0x65,0x0E,0x9D,0xAF,0xB4,0xB7,0x6D,0x63,0xF0,0x69,0x71,0x08,0x97,0x33,0x4F,0x18,0xEA,0x6B,0x0C,0xBF,0x99,0xCD,0x59,0x0A,0x78,0xE3,0xB0,0x50,0xE1,0xBB,0x24,0xC8,0x6D,0x63,0x23,0xA1,0x71,0x06,0xF0,0xCA,0xE3,0xF3,0x0B,0x01,0xE4,0xEB,0x3D,0xB1,0xB5,0xF3,0xA4,0x77,0x1A,0x88,0x0C,0x8A,0xC0,0x6B,0xCD,0x5A,0x82,0xD4,0x10,0x3D,0x04,0x52,0xFD,0x7B,0x54,0x83,0x4C,0x1C,0xF8,0x59,0x5D,0xD7,0x7F,0x82,0xD4,0xAD,0x9E,0xBC,0x1C,0xFD,0x0C,0x9A,0x8C,0xC7,0x87,0xE1,0x0A,0xA4,0xD1,0x68,0x84,0x74,0x20,0x8B,0x69,0xFF,0x7A,0xD4,0xDA,0x69,0x86,0xE5,0xF6,0x2A,0x34,0xAC,0x30,0x93,0xE0,0xFB,0x1E,0xFE,0x8A,0xE3,0xA9,0x6F,0x6A,0xAE,0x09,0xB0,0xE8,0xF6,0xE7,0xA2,0xB6,0x5C,0x73,0x87,0x99,0x9C,0xEC,0xCA,0x43,0xCC,0x33,0xF0,0x26,0xDC,0x19,0xBB,0xFD,0x86,0x7C,0x48,0x12,0x7C,0xFF,0x57,0x9D,0x1D,0x71,0xAF,0xF0,0xC4,0xA0,0xE2,0x0F,0x9F,0xDF,0xD5,0x99,0xA6,0x16,0x9D,0xF1,0xB8,0x5F,0x60,0x51,0xE0,0x22,0x90,0xDF,0x6F,0x5E,0xDE,0x4F,0x29,0xBB,0x6F,0x0C,0x8F,0x80,0x6D,0x68,0x50,0xC6,0x53,0x4E,0xCD,0xDC,0xCD,0x75,0xBB,0x8E,0x4A,0x09,0x7C,0x70,0x44,0x55,0x85,0x74,0x0F,0x82,0x2E,0x5C,0xEB,0xB0,0xE1,0x9E,0xAC,0x82,0xBB,0x78,0xEB,0xDE,0x2C,0xA6,0x0A,0x81,0x0A,0xC6,0xC5,0x41,0x19,0xFD,0x64,0x27,0xDA,0x8A,0x01,0x55,0xEF,0x48,0x65,0x35,0x15,0xA9,0x19,0xB2,0x99,0xA3,0x06,0xFD,0x3C,0x62,0xB5,0x05,0xA6,0x91,0x1D,0xB2,0xB5,0x6C,0xA2,0xF2,0x96,0xE4,0x87,0xBA,0x02,0xC5,0x46,0xEC,0xA2,0x78,0x3A,0xDE,0x8E,0x46,0xA8,0xC7,0x8E,0xB1,0xF3,0xD7,0xC0,0x4B,0xB2,0x45,0x48,0xF9,0x23,0x83,0xE4,0x75,0xCE,0x6E,0x57,0x2D,0x8D,0xE1,0xBF,0xA9,0xB3,0xE3,0x5D,0x9B,0xD6,0xC7,0x95,0x47,0xB5,0x92,0xC9,0x56,0x93,0x75,0x00,0x10,0xA3,0xD2,0x2C,0xBB,0x31,0xAA,0x5A,0x4A,0xBE,0x94,0x89,0x78,0x31,0xB1,0xED,0x92,0x87,0x63,0x1F,0x00,0x6A,0x73,0x5C,0x36,0xBC,0x84,0xA8,0xC8,0x74,0x97,0xEE,0xA4,0x87,0x38,0x01,0xA7,0x33,0xF3,0x5B,0x32,0x8C,0x7D,0x2C,0xCB,0xE4,0xA4,0x1C,0x19,0x3D,0x22,0xF9,0x72,0x57,0x1B,0xA7,0x63,0x0B,0x33,0x08,0x07,0x93,0x49,0x8C,0xC8,0x5E,0x6E,0xEA,0x1C,0x41,0x29,0x14,0x45,0x9D,0xA1,0x75,0xA6,0xDB,0x86,0x58,0xD0,0xBD,0x7A,0x82,0x3F,0xAB,0x28,0x6E,0xDC,0x20,0xC7,0x85,0xC4,0x0B,0xFD,0x53,0x99,0x24,0xA2,0x4A,0xF4,0xE3,0xD3,0x7B,0xD7,0x81,0x35,0x36,0x77,0xC7,0x6D,0x46,0x72,0x09,0x8F,0x5B,0xDD,0x17,0x01,0x70,0x12,0x57,0x1D,0x9A,0xFD,0xA0,0x5A,0x40,0xAB,0x56,0x99,0x8E,0x40,0xF5,0xE3,0x59,0xC4,0x3D,0xFE,0x32,0xCA,0x10,0xA4,0x5B,0xF0,0x8F,0x67,0xD1,0x28,0xC2,0x4B,0x1A,0xCC,0x03,0xCB,0xAC,0x46,0xBA,0x6C,0xA5,0xA5,0x32,0xC1,0x05,0xE9,0x1E,0x0C,0x77,0xED,0x59,0xFB,0x53,0x4A,0xEE,0xCD,0x68,0x73,0x5A,0x49,0x78,0x17,0x7B,0xB5,0xA6,0x56,0xB9,0xF8,0x3B,0x20,0x2B,0xB6,0x04,0xD6,0x1A,0x24,0x57,0x4C,0x16,0x65,0x6E,0x51,0x2C,0x0A,0x4C,0xC6,0xF5,0x97,0xB3,0x26,0x85,0x73,0xE1,0x05,0x39,0xD1,0xBA,0x77,0x5E,0xD8,0x3B,0xB6,0x80,0xBB,0x91,0x15,0x01,0x1C,0x6A,0xD4,0x3F,0xBB,0x66,0xFB,0x37,0xC4,0x67,0x24,0x90,0x60,0xA1,0x58,0x6D,0xF2,0x7B,0x2C,0xEF,0xA6,0x52,0x65,0xCC,0xB9,0x05,0x1E,0x46,0x80,0x00,0xCC,0xAE,0x24,0xF0,0x8B,0xA9,0x41,0xA8,0x18,0x0A,0x64,0xBB,0x62,0x4F,0x14,0x6C,0x8E,0xC5,0x62,0x36,0x3B,0x32,0xC3,0x69,0xF6,0x29,0x97,0xC4,0xB1,0x37,0x5D,0xD7,0xDE,0x64,0x72,0x5A,0x59,0x85,0x29,0x24,0x42,0x73,0xCA,0xF8,0x39,0x89,0x13,0xC6,0xFC,0x01,0x52,0x26,0x83,0xCF,0x1F,0x9F,0x96,0x5C,0x49,0x1A,0xBE,0x7A,0x55,0x4F,0x00,0x19,0x51,0x4E,0xD9,0x8D,0x75,0xEB,0x8B,0xB8,0x56,0x5F,0x77,0xC1,0x95,0xF6,0x29,0xF9,0x81,0x63,0x49,0x4B,0x4A,0xA2,0x67,0x4F,0x92,0xA4,0x1D,0xCB,0x67,0xED,0xD1,0xD8,0x18,0xA5,0xB9,0x89,0x93,0xD0,0xB1,0x19,0x8B,0xB6,0xBE,0xDA,0xBB,0xB4,0x86,0xBC,0x6F,0xDE,0x03,0x94,0x33,0xE8,0x42,0xBA,0xC5,0x68,0xA5,0xB4,0xEA,0xCC,0x02,0x8C,0xC2,0x54,0x4B,0x57,0xD8,0x88,0x38,0x48,0xDD,0xDE,0xE2,0xE9,0x67,0xEA,0x85,0xA6,0x10,0x2B,0xD0,0xAB,0xDD,0xA4,0x1C,0x3D,0x78,0x44,0x7B,0xEE,0x1D,0x49,0x49,0x44,0x9A,0xBA,0xA9,0xB3,0x37,0x7E,0x8C,0xED,0xCF,0x04,0xA5,0x00,0xFD,0x1A,0x69,0x16,0xE2,0x69,0x83,0xE6,0x4B,0x5E,0x96,0xFE,0xF8,0x7B,0x32,0xA0,0x60,0x44,0x4D,0x37,0x44,0x09,0x26,0x24,0x53,0xCB,0x13,0x76,0xC3,0x49,0xA8,0xB5,0xD1,0x76,0x7B,0x1E,0x29,0x91,0xA1,0xA6,0x04,0x4E,0x0F,0x58,0x83,0x1B,0xD1,0x1F,0x12,0x15,0x96,0x75,0xD2,0x15,0xD7,0xEA,0xA7,0x48,0x07,0xC9,0x95,0xFE,0x22,0x01,0x7E,0x30,0x48,0x2D,0xB8,0xA4,0xB0,0x9C,0xA7,0x80,0x08,0x22,0xC7,0x5C,0x92,0xFF,0x64,0x9F,0xC0,0x72,0x8F,0x5A,0x1D,0x44,0xEF,0xE7,0xD0,0xFF,0x14,0x72,0x74,0x15,0x2D,0x5F,0x2F,0x60,0x34,0x2C,0x8F,0x5F,0x95,0x1D,0x8C,0x95,0xF8,0x3C,0x1D,0x54,0x61,0x3A,0x18,0x2D,0x9D,0xCA,0x68,0xF5,0x4F,0xD5,0x50,0x47,0xF1,0xF9,0x0C,0xFE,0xCC,0x04,0xD7,0x33,0xDF,0xA8,0x2C,0xFF,0x26,0x18,0xF2,0x9A,0x4D,0xB4,0xF7,0xE1,0xE5,0x9D,0xEA,0xD5,0x8C,0xA6,0x5D,0x07,0xCC,0x90,0xC2,0x5F,0x80,0x4A,0x89,0x5D,0x6A,0x82,0xF9,0x37,0x54,0x51,0xCC,0x55,0x50,0x6D,0x27,0x6F,0xBF,0x78,0x3F,0x7D,0x4D,0x53,0xB9,0xBF,0xB8,0x3D,0xBE,0x4A,0x87,0x71,0xAF,0xE2,0x1A,0xC5,0x43,0x98,0x3D,0x68,0x03,0x4B,0xAD,0xC9,0x80,0xF9,0x43,0x45,0x27,0xF9,0xED,0xAA,0x2E,0x22,0x86,0x46,0xFD,0xF7,0x5B,0x44,0x89,0x9E,0x74,0x9C,0xF4,0xC9,0xE5,0xB3,0x45,0x22,0x23,0x85,0xA4,0x42,0x43,0x82,0x60,0x3A,0xD6,0xEF,0xC2,0x4C,0x56,0xE7,0x69,0x02,0x8F,0x43,0x94,0xF2,0xF6,0x22,0x0A,0x9B,0x39,0x0D,0x39,0x5E,0x41,0x24,0x98,0xE5,0x7A,0x08,0xBA,0xD9,0x27,0xB8,0xBD,0x5D,0x76,0xE1,0x8E,0x8F,0xEB,0x45,0x7F,0xCB,0xD3,0x24,0x8D,0x21,0x82,0x36,0xB0,0x77,0x83,0xE5,0x7F,0xBF,0xA0,0x3C,0x29,0x2A,0x9F,0x57,0x19,0xE6,0xAE,0xF2,0xEE,0xA3,0xFA,0xB2,0xCA,0xEE,0xD5,0x44,0x2E,0x89,0xBF,0xFB,0x23,0x6C,0xB1,0x3D,0xB2,0xCF,0x9C,0x35,0xA3,0x8C,0x33,0x8C,0x37,0x7C,0x47,0x5D,0xAF,0x45,0xF8,0xEA,0x82,0x2F,0x9A,0xAA,0xC1,0x34,0x25,0xFB,0xD4,0x3D,0x3D,0xD9,0x22,0x93,0x67,0xF0,0xB3,0x68,0x7D,0x7E,0x82,0xAC,0x5E,0xC2,0xFC,0x7C,0xDB,0x69,0xC9,0x9A,0x4E,0xB1,0xB8,0xE4,0x54,0x65,0xC6,0xA5,0x3F,0x16,0xAC,0x0C,0x4E,0x0C,0x97,0x0B,0x8C,0x73,0x2A,0xF5,0x15,0xC0,0x9E,0xAF,0x25,0x59,0x6F,0x64,0xA0,0x4A,0xE4,0x62,0x10,0x37,0xB8,0x84,0x1F,0xD2,0xB1,0xBB,0xCB,0x31,0x0E,0xA2,0x3E,0x12,0x2B,0x0B,0x9A,0xB9,0x6D,0x8F,0x77,0x02,0x95,0x2D,0x0E,0x96,0xE4,0xCF,0x79,0xC2,0xA3,0x0D,0xF0,0x09,0x1A,0xCD,0xA9,0x14,0x79,0xEE,0x29,0x79,0xB0,0x05,0x49,0x97,0xC4,0x8F,0x6A,0x0E,0x90,0x9B,0xC5,0x2A,0x94,0x34,0x59,0xAF,0x25,0x55,0x39,0x69,0xEB,0x31,0xCE,0x76,0x85,0x36,0x9A,0x7F,0xB0,0x14,0x56,0x1B,0x46,0x97,0xB8,0xBC,0xE2,0x20,0x98,0x31,0x36,0xE5,0xEB,0x23,0x03,0xCC,0xA4,0xEA,0xDD,0x4C,0x6C,0xC7,0x4E,0xA2,0xFE,0x69,0xD4,0x48,0xAE,0x6E,0xD9,0x53,0xA8,0x03,0x63,0xDD,0xED,0x55,0x91,0xB2,0x7A,0x1E,0xA9,0x56,0xDF,0x08,0x1C,0xE9,0x9A,0xA5,0x9D,0xFC,0x78,0x9D,0x9D,0x8F,0xAE,0x95,0x2B,0x07,0x37,0x09,0x9D,0x46,0x7D};

    //for (uint32_t i=0; i<48; i++) {
    //    seed[i] = i;
	//}

   
    //int model=1, location =1;
    int is_secret_recovery[1000];
    for(uint32_t i=0; i<1; i++){
        is_secret_recovery[i]=0;
    }
    
    int count=0;
    const uint32_t mlen = sizeof(m);
    //randombytes(m, mlen);
    unsigned long long smlen = 0;
    //unsigned char *m1 = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
    //unsigned char *sm = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
    unsigned char sm[mlen+CRYPTO_BYTES];
    unsigned char pk[CRYPTO_PUBLICKEYBYTES] = {0}, sk[CRYPTO_SECRETKEYBYTES] = {0};
    
    for(int k=0; k<1000; k++){
        
        initialize_csprng(&platform_csprng_state,
                      (const unsigned char *)seed,
                     48);
        randombytes(seed, 48);

        //  const uint32_t mlen = sizeof(m);
          randombytes(m, mlen);
        //  unsigned long long smlen = 0;
        //  unsigned char *m1 = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
        //  unsigned char *sm = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
        //  unsigned char pk[CRYPTO_PUBLICKEYBYTES] = {0}, sk[CRYPTO_SECRETKEYBYTES] = {0};

        int ret_val;
        if ((ret_val = crypto_sign_keypair(pk, sk)) != 0) {
            printf("crypto_sign_keypair returned <%d>\n", ret_val);
            return -1;
        }
        //int model=1, location =1;
        int count1=0;

        int secret_flag[NUM_KEYPAIRS-1];
        for(uint32_t i=0; i<NUM_KEYPAIRS-1; i++){
            secret_flag[i]=0;
        }
        int num_rec_sec=0;
        while(num_rec_sec!=NUM_KEYPAIRS-1){
            if ((ret_val = crypto_sign(sm, &smlen, m, mlen, sk, is_secret_recovery, k, &num_rec_sec, secret_flag)) != 0)
            {
                printf("crypto_sign returned <%d>\n", ret_val);
                return -1;
            }
            count1++;
        
        
        //char signature= (sign_t *)(sm + mlen);
        //fprintBstr(stdout, "sm = ", sm, smlen)
        /*unsigned long long smlen = 0, mlen1;
        if ( (ret_val = crypto_sign_open(m1, &mlen1, sm, smlen, pk)) != 0) {
            printf("crypto_sign_open returned <%d>\n", ret_val);
            //return -1;
        }*/
           // printf("Num of secret: %d\n", num_rec_sec);
        }

        printf("Number of fault to recover full secret at at %d iteration is %d\n", k, count1);
        //num_rec_sec=0;
        // free(m1);
        // free(sm);
    }
        
        printf("all good\n");
    /*if(count==1000){
        printf("Full secret recovery is done for 1000 cases\n");
    }*/
   //free(m1);
    //free(sm);
    return 0; 
}

/*******************************Updated Attack simulation function*****************/

/*int test_key_recovery(int* num_cols){  
    
    pubkey_t pk;
    prikey_t sk;
    LESS_keygen(&sk,&pk);

    SHAKE_STATE_STRUCT sk_shake_state;
    initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);*/

     /* generation, hence NUM_KEYPAIRS-1 */
    /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
    for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }
    monomial_t final_mono_secret[NUM_KEYPAIRS-1];
    monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];

    for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_mat_seed_expand(&private_Q_inv[i], monomial_seeds[i]);
    }

    monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

    for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
    }

    int count_mono_coeff[NUM_KEYPAIRS-1]={0};
    int total_count_coeff = 0;

    sign_t signature;
    char message[8] = "Signme!";      
    LESS_sign(&sk,message,8,&signature);*/  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

    /*uint8_t fixed_weight_string[T] = {0};
    expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

    unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
    memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
    unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

    int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
    unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);

    monomial_t Q_tilde;
    normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
    #ifdef COMPRESS_CMT_COLUMNS
    uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
    #endif
    monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


    rref_generator_mat_t G0_rref;
    generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
    generator_mat_t full_G0;
    generator_rref_expand(&full_G0,&G0_rref);

    int IS_J[N]={0}, IS_J_star={0};
    int employed_monoms = 0, F;
    monomial_action_IS_t mono_action;
    for(int i = 0; i < t; i++) {
        F = fixed_weight_string[i];
        if ( F!= 0){
           // if(count_mono_coeff[F-1]<N) {
               monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
               prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

               expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
               find_partial_monomial_update2(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action, IS_J);



               total_count_coeff-=count_mono_coeff[F-1];
               count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
               total_count_coeff+=count_mono_coeff[F-1];


               
            //}  
        employed_monoms++;
        break;
        }

    }

    monomial_t mono_partial_secret_inv;
    for(int i=0;i<N;i++)
    {
        mono_partial_secret_inv.permutation[i] = N+1;
        mono_partial_secret_inv.coefficients[i] = 0;
    }

    for(int i=0;i<N;i++)
    {
        if(mono_partial_secret[F-1].permutation[i] != N+1)
        {
            mono_partial_secret_inv.permutation[mono_partial_secret[F-1].permutation[i]] = i;
            mono_partial_secret_inv.coefficients[mono_partial_secret[F-1].permutation[i]] = mono_partial_secret[F-1].coefficients[i];
        }
    }

    for(int i=0;i<N;i++) 
                        printf("%d  ", mono_partial_secret[F-1].permutation[i]);
    printf("\n--------------------------\n");

    for(int i=0;i<N;i++) 
                        printf("%d  ", mono_partial_secret_inv.permutation[i]);
    printf("\n--------------------------\n");


    for(int i=0;i<N;i++) 
                        printf("%d  ", private_Q_inv[F-1].permutation[i]);
    printf("\n--------------------------\n");


    generator_mat_t G_hat;
    expand_to_rref(&G_hat, pk.SF_G[F-1]);

    invertible_mat_t G_hat_J_star, G_0_J, S, G_tmp;

    int k=0;*/
    /*
    for(int i=0; i<N;i++){
        if(IS_J[i] == 1){
            for(int j=0;j<K;j++){
                G_0_J.values[k][j] = full_G0.values[i][j];
            }
        }
        k++;
    }
    */
    /*for(int i=0; i<N;i++){
        if(mono_partial_secret[F-1].permutation[i] != N+1){
            for(int j=0;j<K;j++){
                FQ_ELEM tmp = fq_inv(mono_partial_secret[F-1].coefficients[i]);
                tmp = fq_red((FQ_DOUBLEPREC)tmp * (FQ_DOUBLEPREC)full_G0.values[j][i]);
                G_0_J.values[j][k] = tmp;
            }
            k++;
        }
    }

    k=0;
    for(int i=0;i<N;i++){
        if(mono_partial_secret[F-1].permutation[i] != N+1){
            for(int j=0;j<K;j++){
                G_hat_J_star.values[j][k] = G_hat.values[j][mono_partial_secret[F-1].permutation[i]];
            }
            k++;
        }
        
    }

    generator_mat_t G_left, G_right;

    G_tmp = G_0_J;
    matrix_inverse(&G_0_J);
    
    mul_invertible_invertible(&S, &G_hat_J_star, &G_0_J);*/
    
    /*
    monomial_mat_inv(&mono_partial_secret_inv, &private_Q_inv[F-1]);

    generator_monomial_mul(&G_left, &full_G0, &mono_partial_secret_inv);

    mul_invertible_generator(&G_right, &S, &G_left);

    for(int i=0;i<K;i++){
        for(int j=0;j<N;j++)
        {
            //if(j%12==0) printf("\n");
            if(G_right.values[i][j] != G_hat.values[i][j]) printf("1 ");
        }
        printf("\n------ ----------------- --------------------\n");
    }
    */
    
    //matrix_inverse(&S);

    
    //mul_invertible_invertible(&G_0_J, &S, &G_hat_J_star);

    //for(int i=0;i<K;i++)
    //{
    //    for(int j=0;j<K;j++)
    //    {
    //        if(G_tmp.values[i][j] != G_0_J.values[i][j])
    //            printf("\nError\n");
    //    }
    //}
    //mul_invertible_generator(&G_left, &S, &G_hat);

    //monomial_mat_inv(&mono_partial_secret_inv, &private_Q_inv[F-1]);

    //generator_monomial_mul(&G_right, &full_G0, &mono_partial_secret_inv);

    //for(int i=0;i<K;i++){
    //    for(int j=0;j<N;j++)
    //    {
            //if(j%12==0) printf("\n");
    //        if(G_right.values[i][j] != G_left.values[i][j]) printf("1 ");
    //    }
        //printf("\n------ ----------------- --------------------\n");
    //}
    

    /*for(int i=0;i<N;i++)
    {
        for(FQ_ELEM e = 1; e<Q; e++){
            int j = compare(&G_left, &full_G0, e, i);
            if(j!=N+1) printf("%d ", j);
        }
    }
    printf("\n");
    
    


    for(int i=0; i<NUM_KEYPAIRS-1; i++){
        partial_monomial_transpose(&final_mono_secret[i], &private_Q_inv[i]);
    }

    int res;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        for(int j=0; j<N; j++){
            if(mono_partial_secret[i].permutation[j]!=N+1){
                if(mono_partial_secret[i].coefficients[j]!=final_mono_secret[i].coefficients[j]
                    ||mono_partial_secret[i].permutation[j]!=final_mono_secret[i].permutation[j]){
                        fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                    res = failure;
             }
            }
        }
    }
    res = success;

    if(res == success)
        *num_cols += total_count_coeff;
    return res;

}


int key_recovery_full(int* num_cols){  
    
    pubkey_t pk;
    prikey_t sk;
    LESS_keygen(&sk,&pk);

    SHAKE_STATE_STRUCT sk_shake_state;
    initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);*/

     /* generation, hence NUM_KEYPAIRS-1 */
    /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
    for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }
    monomial_t final_mono_secret[NUM_KEYPAIRS-1];
    monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];

    for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_mat_seed_expand(&private_Q_inv[i], monomial_seeds[i]);
    }

    monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

    for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
    }

    int count_mono_coeff[NUM_KEYPAIRS-1]={0};
    int total_count_coeff = 0;

    sign_t signature;
    char message[8] = "Signme!";      
    LESS_sign(&sk,message,8,&signature);*/  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

    /*uint8_t fixed_weight_string[T] = {0};
    expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

    unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
    memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
    unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

    int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
    unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);

    monomial_t Q_tilde;
    normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
    #ifdef COMPRESS_CMT_COLUMNS
    uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
    #endif
    monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


    rref_generator_mat_t G0_rref;
    generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
    generator_mat_t full_G0;
    generator_rref_expand(&full_G0,&G0_rref);

    int IS_J[N]={0}, IS_J_star={0};
    int employed_monoms = 0, F;
    monomial_action_IS_t mono_action;
    for(int i = 0; i < t; i++) {
        F = fixed_weight_string[i];
        if ( F!= 0){
            printf("%d\n",F);
            if(count_mono_coeff[F-1]<N) {
                monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
                prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

                expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
                find_partial_monomial_update2(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action, IS_J);



                total_count_coeff-=count_mono_coeff[F-1];
                
                total_count_coeff+=count_mono_coeff[F-1];

                generator_mat_t G_hat;
                expand_to_rref(&G_hat, pk.SF_G[F-1]);

                invertible_mat_t G_hat_J_star, G_0_J, S, G_tmp;

                int k=0;
                for(int x=0; x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            FQ_ELEM tmp = fq_inv(mono_partial_secret[F-1].coefficients[x]);
                            tmp = fq_red((FQ_DOUBLEPREC)tmp * (FQ_DOUBLEPREC)full_G0.values[j][x]);
                            G_0_J.values[j][k] = tmp;
                        }
                        k++;
                    }
                }

                k=0;
                for(int x=0;x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            G_hat_J_star.values[j][k] = G_hat.values[j][mono_partial_secret[F-1].permutation[x]];
                        }
                        k++;
                    }
                    
                }

                generator_mat_t G_left, G_right;

                G_tmp = G_0_J;

                matrix_inverse(&G_0_J);
                mul_invertible_invertible(&S, &G_hat_J_star, &G_0_J);
                matrix_inverse(&S);
                mul_invertible_generator(&G_left, &S, &G_hat);
                for(int x=0;x<N;x++)
                {
                    for(FQ_ELEM e = 1; e<Q; e++){
                        int j = compare(&G_left, &full_G0, e, x);
                        //if(j!=N+1) printf("%d %d\n", e, j);
                        if(j!=N+1) {
                            mono_partial_secret[F-1].permutation[x] = j;
                            mono_partial_secret[F-1].coefficients[x] = fq_inv(e);
                        }
                    }
                }
                count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
            } 

        employed_monoms++;
        
        }

    }

    //fprintf(stderr, "%d \n", fq_red((FQ_DOUBLEPREC)103*(FQ_DOUBLEPREC)37));

    //for(int i=0; i<NUM_KEYPAIRS-1; i++){
    //    partial_monomial_transpose(&final_mono_secret[i], &private_Q_inv[i]);
    //}

    printf("\n------------------\n");
    int res;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        res = success;
        for(int j=0; j<N; j++){
            
                if(mono_partial_secret[i].coefficients[j]!=private_Q_inv[i].coefficients[j]
                    ||mono_partial_secret[i].permutation[j]!=private_Q_inv[i].permutation[j]){
                       // fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                    res = failure;
             }
        }
        if(res == failure)
            printf("%d\n", i+1);
    }
    res = success;

    if(res == success)
        *num_cols += total_count_coeff;
    return res;

}*/

// Attack simulations //


/*int SIM_secret_key_single_fault(int *num_cols){  
    
    pubkey_t pk;
    prikey_t sk;
    LESS_keygen(&sk,&pk);

    SHAKE_STATE_STRUCT sk_shake_state;
    initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);*/

     /* generation, hence NUM_KEYPAIRS-1 */
    /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
    for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }
    monomial_t final_mono_secret[NUM_KEYPAIRS-1];
    monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];

    for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_mat_seed_expand(&private_Q_inv[i], monomial_seeds[i]);
    }

    monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

    for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
    }

    int count_mono_coeff[NUM_KEYPAIRS-1]={0};
    int total_count_coeff = 0;

    sign_t signature;
    char message[8] = "Signme!";      
    LESS_sign(&sk,message,8,&signature);*/  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

    /*uint8_t fixed_weight_string[T] = {0};
    expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

    unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
    memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
    unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

    int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
    unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);

    monomial_t Q_tilde;
    normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
    #ifdef COMPRESS_CMT_COLUMNS
    uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
    #endif
    monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


    rref_generator_mat_t G0_rref;
    generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
    generator_mat_t full_G0;
    generator_rref_expand(&full_G0,&G0_rref);

    int employed_monoms = 0;
    monomial_action_IS_t mono_action;
    for(int i = 0; i < t; i++) {
        int F = fixed_weight_string[i];
        if ( F!= 0){
            if(count_mono_coeff[F-1]<N) {
               monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
               prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

               expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
               find_partial_monomial_update(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action);
               total_count_coeff-=count_mono_coeff[F-1];
               count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
               total_count_coeff+=count_mono_coeff[F-1];
            }  
        employed_monoms++;
        }
    }


    for(int i=0; i<NUM_KEYPAIRS-1; i++){
        partial_monomial_transpose(&final_mono_secret[i], &private_Q_inv[i]);
    }

    int res;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        for(int j=0; j<N; j++){
            if(mono_partial_secret[i].permutation[j]!=N+1){
                if(mono_partial_secret[i].coefficients[j]!=final_mono_secret[i].coefficients[j]
                    ||mono_partial_secret[i].permutation[j]!=final_mono_secret[i].permutation[j]){
                        fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                    res = failure;
             }
            }
        }
    }
    res = success;

    if(res == success)
        *num_cols += total_count_coeff;
    return res;

}

int SIM_recover_full_secret_key(int *num_sign){  
    
   pubkey_t pk;
   prikey_t sk;
   LESS_keygen(&sk,&pk);

   SHAKE_STATE_STRUCT sk_shake_state;
   initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);*/

     /* generation, hence NUM_KEYPAIRS-1 */
   /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
   for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
   }
   monomial_t final_mono_secret[NUM_KEYPAIRS-1];
   monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];
   
   for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_mat_seed_expand(&private_Q_inv[i], monomial_seeds[i]);
   }

   monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

   for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
   }

   int count_mono_coeff[NUM_KEYPAIRS-1]={0};
   int total_count_coeff = 0, count_iteration=0;

   while(total_count_coeff < N*(NUM_KEYPAIRS-1)){
      count_iteration++;
      sign_t signature;
      char message[8] = "Signme!";*/          /* We do not necessarily need same message */
      //LESS_sign(&sk,message,8,&signature);  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

      /*uint8_t fixed_weight_string[T] = {0};
      expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

      unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
      memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
      unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

      int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
      unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);
      
      monomial_t Q_tilde;
      normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
      #ifdef COMPRESS_CMT_COLUMNS
      uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
      #endif
      monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


      rref_generator_mat_t G0_rref;
      generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
      generator_mat_t full_G0;
      generator_rref_expand(&full_G0,&G0_rref);

      int employed_monoms = 0;
      monomial_action_IS_t mono_action;
      for(int i = 0; i < t; i++) {
         int F = fixed_weight_string[i];
         if ( F!= 0){
            if(count_mono_coeff[F-1]<N) {
               monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
               prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

               expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
               find_partial_monomial_update(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action);
               total_count_coeff-=count_mono_coeff[F-1];
               count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
               total_count_coeff+=count_mono_coeff[F-1];
            }  
            employed_monoms++;
         }
      }
   }

   //printf("The number of iteration is %d\n",count_iteration);
   for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_transpose(&final_mono_secret[i], &mono_partial_secret[i]);
   }
   
   int res;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        for(int j=0; j<N; j++){
            if(private_Q_inv[i].coefficients[j]!=final_mono_secret[i].coefficients[j]
             ||private_Q_inv[i].permutation[j]!=final_mono_secret[i].permutation[j]){
                    fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                res = failure;
             }
        }
    }
    res = success;

    if(res == success)
        *num_sign += count_iteration;
    return res;

}

int SIM_recover_full_secret_key_prob(int *num_sign){  
    
   uint8_t seed[] ={0x83,0xC6,0x53,0x70,0x8F,0xAF,0x3E,0x5F,0x6F,0xBC,0x9D,0xFB,0xE6,0xFB,0x5E,0x83,0xE5,0x72,0xA7,0x68,0x86,0x45,0xD7,0x5D,0x2C,0x48,0x35,0xB2,0x86,0x95,0xDE,0xA4,0xBD,0x70,0x93,0x74,0x0D,0x0F,0xF4,0x32,0x37,0x35,0x4E,0xAD,0x1C,0x97,0x8B,0xC2};
    uint8_t m[] ={0xE3,0xB5,0x7B,0x20,0x83,0x52,0xA8,0x20,0xF6,0x22,0xA6,0x94,0xB7,0xC3,0xF6,0xF2,0x97,0x23,0x9E,0xF0,0xA0,0x69,0x61,0x5D,0xC6,0x64,0xC0,0x2F,0x18,0x22,0xBB,0xA4,0x8E,0x11,0xE3,0x7B,0xD9,0x74,0x9C,0x98,0xFA,0xCE,0xFF,0xFB,0x0F,0xE1,0x79,0x2A,0x38,0x6B,0xE1,0x0C,0xA7,0xB9,0x8C,0xC8,0x74,0xC6,0x8C,0x36,0xF5,0x09,0x6D,0x37,0x18,0xDC,0x93,0xE0,0x73,0x4D,0x6D,0x6F,0x91,0x3E,0x3B,0x95,0x8D,0xC1,0xFD,0x14,0x24,0x81,0x8C,0x94,0x37,0xB0,0xFD,0x59,0x72,0x8E,0xD4,0x6A,0x79,0xFB,0x52,0xC7,0x37,0xA1,0xD1,0xD2,0x6F,0x04,0xEB,0xAC,0x27,0x9A,0x7F,0xF6,0xA9,0x71,0xE2,0xB6,0x95,0x76,0xB7,0x12,0xD9,0x22,0x4E,0xA1,0x8F,0xB9,0xBF,0x4E,0x61,0x3A,0x89,0x35,0xF3,0xB3,0x6A,0x07,0x3B,0x01,0xF3,0x7B,0xDC,0x0B,0x77,0x98,0x1C,0x8F,0x28,0x04,0xE9,0x3C,0x39,0x54,0x19,0x35,0x2B,0x85,0xC8,0xA3,0x2D,0xD7,0x7D,0x41,0xDA,0x9B,0xF3,0xEC,0xB9,0x14,0x17,0x3E,0x80,0xDD,0x1F,0xC0,0x6E,0x8F,0xF5,0xBF,0x0E,0x4F,0x74,0x24,0x84,0x9A,0x15,0xEB,0x7F,0xAF,0x7D,0xE7,0x74,0x56,0xEB,0xB6,0x4D,0x10,0xDC,0x10,0xFE,0xC6,0x25,0x40,0x70,0xC7,0xDF,0x38,0x73,0x97,0x13,0x73,0x72,0xEA,0x3A,0x53,0xDF,0xDA,0x7D,0xA1,0x34,0x14,0xAF,0x2D,0xF1,0x6C,0x1E,0x38,0xC5,0xC7,0x0A,0x5F,0x5F,0x44,0xF7,0x25,0xD6,0x22,0x04,0x92,0x56,0xBB,0x15,0xDC,0x04,0xA8,0xD8,0x46,0xA1,0xA0,0xDA,0xE7,0xE7,0x65,0xA7,0xF0,0x0C,0x49,0x8F,0x1D,0x0B,0x28,0x93,0xB8,0x40,0x5B,0xE4,0xA4,0x3F,0xB7,0xE9,0x78,0x81,0x06,0x9A,0x49,0x13,0x4A,0x2A,0x84,0x71,0x84,0xB8,0x2E,0xB5,0xA6,0x90,0xD8,0x7B,0xAF,0x2F,0x57,0x96,0x19,0xEE,0x19,0xA3,0xD7,0xA7,0xC7,0xEE,0xA7,0x2D,0x6E,0x3F,0xCC,0xF0,0xA8,0x09,0x2B,0xB8,0xD3,0xC6,0xB5,0x51,0xF2,0x7E,0x63,0xE7,0x62,0xA3,0x0B,0x4A,0x4D,0xF2,0xDB,0xC4,0xD1,0x19,0x13,0x9A,0xE1,0xB1,0x35,0xD0,0x6F,0xF8,0x27,0x84,0x69,0x01,0x57,0x77,0x00,0x93,0x5E,0x00,0x11,0xB6,0x54,0x61,0xC2,0xEF,0x9A,0x7B,0x71,0xEE,0xA3,0x3C,0x8C,0xA4,0x51,0x9C,0x7B,0xCF,0xB5,0x57,0xC5,0xE1,0xD4,0x2D,0x92,0x43,0xF2,0xDC,0x34,0x05,0x7F,0x5E,0x0C,0xCB,0x9A,0x45,0x7F,0xC3,0x4D,0xCB,0x10,0xD9,0xB4,0x7F,0x6E,0xC3,0xB9,0x55,0x0D,0x3A,0xE4,0xFD,0x59,0x3D,0xFA,0x3E,0x28,0xC6,0xCC,0xA1,0xFF,0x1E,0xBC,0x9D,0x98,0xDA,0x8D,0xB8,0x69,0xF8,0xC8,0x0B,0xDB,0xF8,0xAD,0x46,0x84,0xAC,0xB6,0xA7,0x79,0xCA,0x9D,0x0A,0x10,0x6F,0x26,0xDA,0x17,0x04,0x37,0x73,0x86,0x26,0x81,0xC5,0xDD,0x2D,0xEB,0x1B,0xCA,0x2C,0xA4,0x8D,0x4F,0xBB,0x4B,0xB7,0xC1,0xF7,0x65,0xDC,0xA3,0xA1,0xD9,0x91,0xD8,0x90,0xB9,0xA8,0x75,0x1C,0xEA,0xFF,0x54,0x39,0x97,0xFA,0xE5,0xB1,0x28,0xAB,0x2E,0xF2,0x2B,0x3B,0xE9,0x44,0x99,0xDF,0xD9,0xD8,0xE7,0x8F,0xB4,0xC8,0x2C,0xA8,0xD2,0x96,0xB0,0x41,0x5E,0x84,0xCA,0x8B,0x5F,0x20,0x24,0x45,0x5B,0x5D,0xEC,0xC8,0xB4,0xCC,0xDC,0x7B,0xC4,0xEE,0x06,0xB4,0xF0,0xC6,0x6E,0x67,0x48,0xFB,0xD0,0x7E,0x3A,0x3B,0xC5,0xB4,0xB6,0x88,0x9C,0x40,0xDC,0x4A,0x97,0xAE,0x3E,0xB4,0x3C,0x39,0x14,0xDE,0xF9,0x76,0xEF,0xE3,0xBF,0xD8,0x4A,0x09,0x3B,0xD6,0x91,0x02,0xD7,0xB3,0x7C,0x89,0xB4,0x58,0xA5,0x5B,0x98,0xA1,0x97,0x4A,0x13,0xA7,0x68,0x5D,0x26,0xE9,0xD8,0x16,0xC7,0x95,0x85,0xBC,0xFC,0x10,0x42,0xC2,0xAF,0x88,0x53,0x4A,0x9F,0xE8,0xB0,0xA6,0xC8,0xC4,0x43,0x55,0xA6,0xD6,0x06,0xF9,0x02,0xDB,0x40,0xD5,0x49,0x02,0x64,0xBF,0x0F,0x35,0x2C,0x27,0x35,0x56,0x33,0xCB,0x09,0x52,0x68,0xD5,0xB8,0xBE,0xC9,0x85,0xA6,0x2D,0x84,0xB2,0x32,0x3F,0xE8,0x14,0x05,0x3F,0x05,0xDE,0xDC,0x22,0x02,0x9D,0x29,0x98,0xBD,0x0B,0xCB,0x25,0x5C,0x16,0x2C,0x4B,0xC0,0x3F,0x60,0xE3,0x58,0x0A,0xC3,0xAE,0x86,0xC3,0x78,0x50,0x11,0x0E,0x9A,0x1B,0xCB,0xD7,0x5F,0x64,0xA0,0xDD,0x60,0xB9,0x41,0xE2,0xF5,0x7D,0xA9,0xD7,0x24,0x98,0xB3,0xEA,0x83,0x24,0xEE,0xA5,0x3D,0xA3,0x89,0x55,0x85,0xED,0x29,0x42,0xB9,0x14,0x0F,0x26,0x08,0x95,0xDC,0x6A,0x11,0x31,0xA4,0xC3,0xAD,0x2B,0x64,0x02,0x8B,0xB8,0xC0,0xFD,0x67,0xE1,0xBE,0x4C,0x07,0xF8,0x08,0xB4,0x7D,0xAE,0xF3,0x06,0xFD,0x95,0x78,0x02,0x5F,0x9C,0x63,0x96,0x60,0x07,0x58,0x37,0xB2,0xC9,0x54,0x73,0xF7,0xF8,0x60,0xD6,0xEA,0x2C,0x53,0xF4,0xBA,0x67,0x7A,0x23,0x45,0xCF,0x21,0x2C,0x77,0x57,0xBB,0x94,0xF1,0xA4,0xF7,0x6D,0x4E,0x96,0x62,0x5F,0x6F,0xE0,0x51,0xB8,0x24,0x6D,0x1B,0x76,0x11,0xBF,0x6F,0xE3,0x25,0xFF,0xFF,0x85,0x14,0xD2,0xF9,0xA3,0x45,0x3F,0x0E,0x77,0xAE,0x8B,0x95,0x8A,0xB5,0xB5,0x67,0xE5,0x41,0xF1,0x56,0xC6,0xF4,0xD3,0x15,0xB4,0xC3,0xC5,0x47,0xD5,0x9B,0xBD,0x0D,0x74,0x03,0xE2,0xE6,0xA4,0x9B,0x9E,0x7D,0x3F,0xDB,0xA3,0x38,0xAD,0xA4,0x18,0x75,0xCE,0xB0,0x38,0x30,0xA8,0x46,0xA1,0xFB,0x26,0x6C,0x0F,0x12,0x28,0xAA,0xD2,0xB7,0x6A,0x2E,0x34,0x04,0x27,0x8D,0xBE,0x48,0x29,0x07,0x20,0x6F,0xA6,0x64,0x87,0xAD,0x2C,0x99,0x98,0x67,0xF8,0x70,0xC8,0xCB,0x7A,0x70,0xB8,0x34,0x37,0xE1,0x4B,0x9E,0x89,0x3B,0xF6,0xB3,0x91,0xDA,0xD7,0x5E,0x84,0x58,0x8E,0x88,0x22,0x46,0xD1,0x61,0x79,0x9A,0xDE,0xA6,0x3A,0xDF,0x1A,0xD7,0x06,0xC0,0xA3,0xB7,0x6B,0xAE,0x59,0x5D,0x84,0xB2,0x1A,0xE9,0xDA,0x30,0xBB,0xC0,0x85,0x69,0x87,0xF2,0xC2,0xC5,0x43,0xD9,0x77,0x74,0x7B,0x8C,0xBD,0x5A,0x61,0x3B,0x92,0x80,0x4E,0xCC,0x52,0x84,0xED,0x23,0x65,0x0E,0x9D,0xAF,0xB4,0xB7,0x6D,0x63,0xF0,0x69,0x71,0x08,0x97,0x33,0x4F,0x18,0xEA,0x6B,0x0C,0xBF,0x99,0xCD,0x59,0x0A,0x78,0xE3,0xB0,0x50,0xE1,0xBB,0x24,0xC8,0x6D,0x63,0x23,0xA1,0x71,0x06,0xF0,0xCA,0xE3,0xF3,0x0B,0x01,0xE4,0xEB,0x3D,0xB1,0xB5,0xF3,0xA4,0x77,0x1A,0x88,0x0C,0x8A,0xC0,0x6B,0xCD,0x5A,0x82,0xD4,0x10,0x3D,0x04,0x52,0xFD,0x7B,0x54,0x83,0x4C,0x1C,0xF8,0x59,0x5D,0xD7,0x7F,0x82,0xD4,0xAD,0x9E,0xBC,0x1C,0xFD,0x0C,0x9A,0x8C,0xC7,0x87,0xE1,0x0A,0xA4,0xD1,0x68,0x84,0x74,0x20,0x8B,0x69,0xFF,0x7A,0xD4,0xDA,0x69,0x86,0xE5,0xF6,0x2A,0x34,0xAC,0x30,0x93,0xE0,0xFB,0x1E,0xFE,0x8A,0xE3,0xA9,0x6F,0x6A,0xAE,0x09,0xB0,0xE8,0xF6,0xE7,0xA2,0xB6,0x5C,0x73,0x87,0x99,0x9C,0xEC,0xCA,0x43,0xCC,0x33,0xF0,0x26,0xDC,0x19,0xBB,0xFD,0x86,0x7C,0x48,0x12,0x7C,0xFF,0x57,0x9D,0x1D,0x71,0xAF,0xF0,0xC4,0xA0,0xE2,0x0F,0x9F,0xDF,0xD5,0x99,0xA6,0x16,0x9D,0xF1,0xB8,0x5F,0x60,0x51,0xE0,0x22,0x90,0xDF,0x6F,0x5E,0xDE,0x4F,0x29,0xBB,0x6F,0x0C,0x8F,0x80,0x6D,0x68,0x50,0xC6,0x53,0x4E,0xCD,0xDC,0xCD,0x75,0xBB,0x8E,0x4A,0x09,0x7C,0x70,0x44,0x55,0x85,0x74,0x0F,0x82,0x2E,0x5C,0xEB,0xB0,0xE1,0x9E,0xAC,0x82,0xBB,0x78,0xEB,0xDE,0x2C,0xA6,0x0A,0x81,0x0A,0xC6,0xC5,0x41,0x19,0xFD,0x64,0x27,0xDA,0x8A,0x01,0x55,0xEF,0x48,0x65,0x35,0x15,0xA9,0x19,0xB2,0x99,0xA3,0x06,0xFD,0x3C,0x62,0xB5,0x05,0xA6,0x91,0x1D,0xB2,0xB5,0x6C,0xA2,0xF2,0x96,0xE4,0x87,0xBA,0x02,0xC5,0x46,0xEC,0xA2,0x78,0x3A,0xDE,0x8E,0x46,0xA8,0xC7,0x8E,0xB1,0xF3,0xD7,0xC0,0x4B,0xB2,0x45,0x48,0xF9,0x23,0x83,0xE4,0x75,0xCE,0x6E,0x57,0x2D,0x8D,0xE1,0xBF,0xA9,0xB3,0xE3,0x5D,0x9B,0xD6,0xC7,0x95,0x47,0xB5,0x92,0xC9,0x56,0x93,0x75,0x00,0x10,0xA3,0xD2,0x2C,0xBB,0x31,0xAA,0x5A,0x4A,0xBE,0x94,0x89,0x78,0x31,0xB1,0xED,0x92,0x87,0x63,0x1F,0x00,0x6A,0x73,0x5C,0x36,0xBC,0x84,0xA8,0xC8,0x74,0x97,0xEE,0xA4,0x87,0x38,0x01,0xA7,0x33,0xF3,0x5B,0x32,0x8C,0x7D,0x2C,0xCB,0xE4,0xA4,0x1C,0x19,0x3D,0x22,0xF9,0x72,0x57,0x1B,0xA7,0x63,0x0B,0x33,0x08,0x07,0x93,0x49,0x8C,0xC8,0x5E,0x6E,0xEA,0x1C,0x41,0x29,0x14,0x45,0x9D,0xA1,0x75,0xA6,0xDB,0x86,0x58,0xD0,0xBD,0x7A,0x82,0x3F,0xAB,0x28,0x6E,0xDC,0x20,0xC7,0x85,0xC4,0x0B,0xFD,0x53,0x99,0x24,0xA2,0x4A,0xF4,0xE3,0xD3,0x7B,0xD7,0x81,0x35,0x36,0x77,0xC7,0x6D,0x46,0x72,0x09,0x8F,0x5B,0xDD,0x17,0x01,0x70,0x12,0x57,0x1D,0x9A,0xFD,0xA0,0x5A,0x40,0xAB,0x56,0x99,0x8E,0x40,0xF5,0xE3,0x59,0xC4,0x3D,0xFE,0x32,0xCA,0x10,0xA4,0x5B,0xF0,0x8F,0x67,0xD1,0x28,0xC2,0x4B,0x1A,0xCC,0x03,0xCB,0xAC,0x46,0xBA,0x6C,0xA5,0xA5,0x32,0xC1,0x05,0xE9,0x1E,0x0C,0x77,0xED,0x59,0xFB,0x53,0x4A,0xEE,0xCD,0x68,0x73,0x5A,0x49,0x78,0x17,0x7B,0xB5,0xA6,0x56,0xB9,0xF8,0x3B,0x20,0x2B,0xB6,0x04,0xD6,0x1A,0x24,0x57,0x4C,0x16,0x65,0x6E,0x51,0x2C,0x0A,0x4C,0xC6,0xF5,0x97,0xB3,0x26,0x85,0x73,0xE1,0x05,0x39,0xD1,0xBA,0x77,0x5E,0xD8,0x3B,0xB6,0x80,0xBB,0x91,0x15,0x01,0x1C,0x6A,0xD4,0x3F,0xBB,0x66,0xFB,0x37,0xC4,0x67,0x24,0x90,0x60,0xA1,0x58,0x6D,0xF2,0x7B,0x2C,0xEF,0xA6,0x52,0x65,0xCC,0xB9,0x05,0x1E,0x46,0x80,0x00,0xCC,0xAE,0x24,0xF0,0x8B,0xA9,0x41,0xA8,0x18,0x0A,0x64,0xBB,0x62,0x4F,0x14,0x6C,0x8E,0xC5,0x62,0x36,0x3B,0x32,0xC3,0x69,0xF6,0x29,0x97,0xC4,0xB1,0x37,0x5D,0xD7,0xDE,0x64,0x72,0x5A,0x59,0x85,0x29,0x24,0x42,0x73,0xCA,0xF8,0x39,0x89,0x13,0xC6,0xFC,0x01,0x52,0x26,0x83,0xCF,0x1F,0x9F,0x96,0x5C,0x49,0x1A,0xBE,0x7A,0x55,0x4F,0x00,0x19,0x51,0x4E,0xD9,0x8D,0x75,0xEB,0x8B,0xB8,0x56,0x5F,0x77,0xC1,0x95,0xF6,0x29,0xF9,0x81,0x63,0x49,0x4B,0x4A,0xA2,0x67,0x4F,0x92,0xA4,0x1D,0xCB,0x67,0xED,0xD1,0xD8,0x18,0xA5,0xB9,0x89,0x93,0xD0,0xB1,0x19,0x8B,0xB6,0xBE,0xDA,0xBB,0xB4,0x86,0xBC,0x6F,0xDE,0x03,0x94,0x33,0xE8,0x42,0xBA,0xC5,0x68,0xA5,0xB4,0xEA,0xCC,0x02,0x8C,0xC2,0x54,0x4B,0x57,0xD8,0x88,0x38,0x48,0xDD,0xDE,0xE2,0xE9,0x67,0xEA,0x85,0xA6,0x10,0x2B,0xD0,0xAB,0xDD,0xA4,0x1C,0x3D,0x78,0x44,0x7B,0xEE,0x1D,0x49,0x49,0x44,0x9A,0xBA,0xA9,0xB3,0x37,0x7E,0x8C,0xED,0xCF,0x04,0xA5,0x00,0xFD,0x1A,0x69,0x16,0xE2,0x69,0x83,0xE6,0x4B,0x5E,0x96,0xFE,0xF8,0x7B,0x32,0xA0,0x60,0x44,0x4D,0x37,0x44,0x09,0x26,0x24,0x53,0xCB,0x13,0x76,0xC3,0x49,0xA8,0xB5,0xD1,0x76,0x7B,0x1E,0x29,0x91,0xA1,0xA6,0x04,0x4E,0x0F,0x58,0x83,0x1B,0xD1,0x1F,0x12,0x15,0x96,0x75,0xD2,0x15,0xD7,0xEA,0xA7,0x48,0x07,0xC9,0x95,0xFE,0x22,0x01,0x7E,0x30,0x48,0x2D,0xB8,0xA4,0xB0,0x9C,0xA7,0x80,0x08,0x22,0xC7,0x5C,0x92,0xFF,0x64,0x9F,0xC0,0x72,0x8F,0x5A,0x1D,0x44,0xEF,0xE7,0xD0,0xFF,0x14,0x72,0x74,0x15,0x2D,0x5F,0x2F,0x60,0x34,0x2C,0x8F,0x5F,0x95,0x1D,0x8C,0x95,0xF8,0x3C,0x1D,0x54,0x61,0x3A,0x18,0x2D,0x9D,0xCA,0x68,0xF5,0x4F,0xD5,0x50,0x47,0xF1,0xF9,0x0C,0xFE,0xCC,0x04,0xD7,0x33,0xDF,0xA8,0x2C,0xFF,0x26,0x18,0xF2,0x9A,0x4D,0xB4,0xF7,0xE1,0xE5,0x9D,0xEA,0xD5,0x8C,0xA6,0x5D,0x07,0xCC,0x90,0xC2,0x5F,0x80,0x4A,0x89,0x5D,0x6A,0x82,0xF9,0x37,0x54,0x51,0xCC,0x55,0x50,0x6D,0x27,0x6F,0xBF,0x78,0x3F,0x7D,0x4D,0x53,0xB9,0xBF,0xB8,0x3D,0xBE,0x4A,0x87,0x71,0xAF,0xE2,0x1A,0xC5,0x43,0x98,0x3D,0x68,0x03,0x4B,0xAD,0xC9,0x80,0xF9,0x43,0x45,0x27,0xF9,0xED,0xAA,0x2E,0x22,0x86,0x46,0xFD,0xF7,0x5B,0x44,0x89,0x9E,0x74,0x9C,0xF4,0xC9,0xE5,0xB3,0x45,0x22,0x23,0x85,0xA4,0x42,0x43,0x82,0x60,0x3A,0xD6,0xEF,0xC2,0x4C,0x56,0xE7,0x69,0x02,0x8F,0x43,0x94,0xF2,0xF6,0x22,0x0A,0x9B,0x39,0x0D,0x39,0x5E,0x41,0x24,0x98,0xE5,0x7A,0x08,0xBA,0xD9,0x27,0xB8,0xBD,0x5D,0x76,0xE1,0x8E,0x8F,0xEB,0x45,0x7F,0xCB,0xD3,0x24,0x8D,0x21,0x82,0x36,0xB0,0x77,0x83,0xE5,0x7F,0xBF,0xA0,0x3C,0x29,0x2A,0x9F,0x57,0x19,0xE6,0xAE,0xF2,0xEE,0xA3,0xFA,0xB2,0xCA,0xEE,0xD5,0x44,0x2E,0x89,0xBF,0xFB,0x23,0x6C,0xB1,0x3D,0xB2,0xCF,0x9C,0x35,0xA3,0x8C,0x33,0x8C,0x37,0x7C,0x47,0x5D,0xAF,0x45,0xF8,0xEA,0x82,0x2F,0x9A,0xAA,0xC1,0x34,0x25,0xFB,0xD4,0x3D,0x3D,0xD9,0x22,0x93,0x67,0xF0,0xB3,0x68,0x7D,0x7E,0x82,0xAC,0x5E,0xC2,0xFC,0x7C,0xDB,0x69,0xC9,0x9A,0x4E,0xB1,0xB8,0xE4,0x54,0x65,0xC6,0xA5,0x3F,0x16,0xAC,0x0C,0x4E,0x0C,0x97,0x0B,0x8C,0x73,0x2A,0xF5,0x15,0xC0,0x9E,0xAF,0x25,0x59,0x6F,0x64,0xA0,0x4A,0xE4,0x62,0x10,0x37,0xB8,0x84,0x1F,0xD2,0xB1,0xBB,0xCB,0x31,0x0E,0xA2,0x3E,0x12,0x2B,0x0B,0x9A,0xB9,0x6D,0x8F,0x77,0x02,0x95,0x2D,0x0E,0x96,0xE4,0xCF,0x79,0xC2,0xA3,0x0D,0xF0,0x09,0x1A,0xCD,0xA9,0x14,0x79,0xEE,0x29,0x79,0xB0,0x05,0x49,0x97,0xC4,0x8F,0x6A,0x0E,0x90,0x9B,0xC5,0x2A,0x94,0x34,0x59,0xAF,0x25,0x55,0x39,0x69,0xEB,0x31,0xCE,0x76,0x85,0x36,0x9A,0x7F,0xB0,0x14,0x56,0x1B,0x46,0x97,0xB8,0xBC,0xE2,0x20,0x98,0x31,0x36,0xE5,0xEB,0x23,0x03,0xCC,0xA4,0xEA,0xDD,0x4C,0x6C,0xC7,0x4E,0xA2,0xFE,0x69,0xD4,0x48,0xAE,0x6E,0xD9,0x53,0xA8,0x03,0x63,0xDD,0xED,0x55,0x91,0xB2,0x7A,0x1E,0xA9,0x56,0xDF,0x08,0x1C,0xE9,0x9A,0xA5,0x9D,0xFC,0x78,0x9D,0x9D,0x8F,0xAE,0x95,0x2B,0x07,0x37,0x09,0x9D,0x46,0x7D};

    //for (uint32_t i=0; i<48; i++) {
    //    seed[i] = i;
	//}

    // init_randombytes(seed, 48);
    initialize_csprng(&platform_csprng_state,
                      (const unsigned char *)seed,
                      48);

    const uint32_t mlen = sizeof(m);
    unsigned long long smlen = 0, mlen1;
    unsigned char *m1 = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
    unsigned char *sm = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
    unsigned char pk[CRYPTO_PUBLICKEYBYTES] = {0}, sk[CRYPTO_SECRETKEYBYTES] = {0};

    int ret_val;
    if ((ret_val = crypto_sign_keypair(pk, sk)) != 0) {
        printf("crypto_sign_keypair returned <%d>\n", ret_val);
        return -1;
    }
    fprintBstr(stdout, "pk = ", pk, CRYPTO_PUBLICKEYBYTES);
    fprintBstr(stdout, "sk = ", sk, CRYPTO_SECRETKEYBYTES);

    if ( (ret_val = crypto_sign(sm, &smlen, m, mlen, sk)) != 0) {
        printf("crypto_sign returned <%d>\n", ret_val);
        return -1;
    }

    fprintBstr(stdout, "sm = ", sm, smlen);
    if ( (ret_val = crypto_sign_open(m1, &mlen1, sm, smlen, pk)) != 0) {
        printf("crypto_sign_open returned <%d>\n", ret_val);
        return -1;
    }

    free(m1);
    free(sm);
    printf("all good\n");
    return 0;

}
*/

/******************************************************
 * 
 * 
 * 
 *                   NEW SIMULATIONS 
 *              WITH IMPROVED KEY-RECOVERY
 * 
 * 
 * 
 * ****************************************************/

/*int SIM_secret_key_single_fault_new(int *num_cols){  
    
    pubkey_t pk;
    prikey_t sk;

    LESS_keygen(&sk,&pk);

    randombytes(sk.compressed_sk, PRIVATE_KEY_SEED_LENGTH_BYTES);*/

    /* expanding it onto private seeds */
   // SHAKE_STATE_STRUCT sk_shake_state;
    //initialize_csprng(&sk_shake_state, sk.compressed_sk, PRIVATE_KEY_SEED_LENGTH_BYTES);

    /* Generating public code G_0 */
    /*csprng_randombytes(pk.G_0_seed, SEED_LENGTH_BYTES, &sk_shake_state);

    rref_generator_mat_t G0_rref;
    generator_sample(&G0_rref, pk.G_0_seed);

    generator_mat_t tmp_full_G;
    generator_rref_expand(&tmp_full_G, &G0_rref);*/

    /* The first private key monomial is an ID matrix, no need for random
     * generation, hence NUM_KEYPAIRS-1 */
    /*unsigned char private_monomial_seeds[NUM_KEYPAIRS - 1][PRIVATE_KEY_SEED_LENGTH_BYTES];
    for (uint32_t i = 0; i < NUM_KEYPAIRS - 1; i++) {
        csprng_randombytes(private_monomial_seeds[i],
                           PRIVATE_KEY_SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }*/

    //SHAKE_STATE_STRUCT sk_shake_state;
    //initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);

     /* generation, hence NUM_KEYPAIRS-1 */
    /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
    for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
    }*/
    /*monomial_t final_mono_secret[NUM_KEYPAIRS-1];
    monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];

    for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_sample_prikey(&private_Q_inv[i], private_monomial_seeds[i]);
      monomial_inv(&private_Q_transpose[i], &private_Q_inv[i]);
    }

    monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

    for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
    }

    int count_mono_coeff[NUM_KEYPAIRS-1]={0};
    int total_count_coeff = 0;

    sign_t signature;
    char message[8]; 
    csprng_randombytes(message,7,&sk_shake_state);
    message[8]='\0';

    LESS_sign(&sk,message,8,&signature);*/  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

    /*uint8_t fixed_weight_string[T] = {0};
    expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

    unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
    memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
    unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

    int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
    unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);

    monomial_t Q_tilde;
    normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
    #ifdef COMPRESS_CMT_COLUMNS
    uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
    #endif
    monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


    rref_generator_mat_t G0_rref;
    generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
    generator_mat_t full_G0;
    generator_rref_expand(&full_G0,&G0_rref);

    int employed_monoms = 0;
    monomial_action_IS_t mono_action;
    for(int i = 0; i < t; i++) {
        int F = fixed_weight_string[i];
        if ( F!= 0){
            //printf("%d\n",F);
            if(count_mono_coeff[F-1]<N) {
                monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
                prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

                expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
                find_partial_monomial_update(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action);

                // Get F-th public key

                generator_mat_t G_hat;
                expand_to_rref(&G_hat, pk.SF_G[F-1]);

                invertible_mat_t G_hat_J_star, G_0_J, S, G_tmp;

                int k=0;
                for(int x=0; x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            FQ_ELEM tmp = fq_inv(mono_partial_secret[F-1].coefficients[x]);
                            tmp = fq_red((FQ_DOUBLEPREC)tmp * (FQ_DOUBLEPREC)full_G0.values[j][x]);
                            G_0_J.values[j][k] = tmp;
                        }
                        k++;
                    }
                }

                k=0;
                for(int x=0;x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            G_hat_J_star.values[j][k] = G_hat.values[j][mono_partial_secret[F-1].permutation[x]];
                        }
                        k++;
                    }
                    
                }

                generator_mat_t G_left, G_right;

                G_tmp = G_0_J;

                matrix_inverse(&G_0_J);

                // Recovering S where G_hat = S * G_0 * Q^{-1}
                mul_invertible_invertible(&S, &G_hat_J_star, &G_0_J);
                matrix_inverse(&S);
                mul_invertible_generator(&G_left, &S, &G_hat);
                
                for(int x=0;x<N;x++)
                {
                    for(FQ_ELEM e = 1; e<Q; e++){
                        int j = compare(&G_left, &full_G0, e, x);
                        //if(j!=N+1) printf("%d %d\n", e, j);
                        if(j!=N+1) {
                            mono_partial_secret[F-1].permutation[x] = j;
                            mono_partial_secret[F-1].coefficients[x] = fq_inv(e);
                        }
                    }
                }

                count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
                total_count_coeff+=1;
                
            } 

            employed_monoms++;
        
        }
    }


    int res = success;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        for(int j=0; j<N; j++){
            if(mono_partial_secret[i].permutation[j]!=N+1){
                if(mono_partial_secret[i].coefficients[j]!=private_Q_inv[i].coefficients[j]
                    ||mono_partial_secret[i].permutation[j]!=private_Q_inv[i].permutation[j]){
                        //fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                    res = failure;
                }
            }
            else break;
        }
    }
    //res = success;

    if(res == success)
        *num_cols += total_count_coeff;
    return res;

}

int SIM_recover_full_secret_key_new(int *num_sign){  
    
   pubkey_t pk;
   prikey_t sk;
   LESS_keygen(&sk,&pk);

   SHAKE_STATE_STRUCT sk_shake_state;
   initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);*/

     /* generation, hence NUM_KEYPAIRS-1 */
   /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
   for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
   }
   monomial_t final_mono_secret[NUM_KEYPAIRS-1];
   monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];
   
   for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_mat_seed_expand(&private_Q_inv[i], monomial_seeds[i]);
   }

   monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

   for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
   }

   int count_mono_coeff[NUM_KEYPAIRS-1]={0};
   int total_count_coeff = 0, count_iteration=0;

   while(total_count_coeff < (NUM_KEYPAIRS-1)){
      count_iteration++;
      sign_t signature;
      char message[8] = "Signme!";*/          /* We do not necessarily need same message */
      //LESS_sign(&sk,message,8,&signature);  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

      /*uint8_t fixed_weight_string[T] = {0};
      expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

      unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
      memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
      unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

      int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
      unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);
      
      monomial_t Q_tilde;
      normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
      #ifdef COMPRESS_CMT_COLUMNS
      uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
      #endif
      monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


      rref_generator_mat_t G0_rref;
      generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
      generator_mat_t full_G0;
      generator_rref_expand(&full_G0,&G0_rref);

      int employed_monoms = 0;
      monomial_action_IS_t mono_action;
      for(int i = 0; i < t; i++) {
        int F = fixed_weight_string[i];
        if ( F!= 0){
            //printf("%d\n",F);
            if(count_mono_coeff[F-1]<N) {
                monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
                prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

                expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
                find_partial_monomial_update(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action);

                // Get F-th public key

                generator_mat_t G_hat;
                expand_to_rref(&G_hat, pk.SF_G[F-1]);

                invertible_mat_t G_hat_J_star, G_0_J, S, G_tmp;

                int k=0;
                for(int x=0; x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            FQ_ELEM tmp = fq_inv(mono_partial_secret[F-1].coefficients[x]);
                            tmp = fq_red((FQ_DOUBLEPREC)tmp * (FQ_DOUBLEPREC)full_G0.values[j][x]);
                            G_0_J.values[j][k] = tmp;
                        }
                        k++;
                    }
                }

                k=0;
                for(int x=0;x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            G_hat_J_star.values[j][k] = G_hat.values[j][mono_partial_secret[F-1].permutation[x]];
                        }
                        k++;
                    }
                    
                }

                generator_mat_t G_left, G_right;

                G_tmp = G_0_J;

                matrix_inverse(&G_0_J);

                // Recovering S where G_hat = S * G_0 * Q^{-1}
                mul_invertible_invertible(&S, &G_hat_J_star, &G_0_J);
                matrix_inverse(&S);
                mul_invertible_generator(&G_left, &S, &G_hat);
                
                for(int x=0;x<N;x++)
                {
                    for(FQ_ELEM e = 1; e<Q; e++){
                        int j = compare(&G_left, &full_G0, e, x);
                        //if(j!=N+1) printf("%d %d\n", e, j);
                        if(j!=N+1) {
                            mono_partial_secret[F-1].permutation[x] = j;
                            mono_partial_secret[F-1].coefficients[x] = fq_inv(e);
                        }
                    }
                }

                
                count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
                total_count_coeff+=1;
                
            } 

            employed_monoms++;
        
        }
      }
   }

   //printf("The number of iteration is %d\n",count_iteration);
   
   int res;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        for(int j=0; j<N; j++){
            if(private_Q_inv[i].coefficients[j]!=mono_partial_secret[i].coefficients[j]
             ||private_Q_inv[i].permutation[j]!=mono_partial_secret[i].permutation[j]){
                    fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                res = failure;
             }
        }
    }
    res = success;

    if(res == success)
        *num_sign += count_iteration;
    return res;

}*/

/*int SIM_recover_full_secret_key_prob_new(int *num_sign){  
    
   pubkey_t pk;
   prikey_t sk;Gadget
   LESS_keygen(&sk,&pk);

   SHAKE_STATE_STRUCT sk_shake_state;
   initialize_csprng(&sk_shake_state,sk.compressed_sk,SEED_LENGTH_BYTES);*/

     /* generation, hence NUM_KEYPAIRS-1 */
   /*unsigned char monomial_seeds[NUM_KEYPAIRS-1][SEED_LENGTH_BYTES];
   for (int i = 0; i < NUM_KEYPAIRS-1; i++) {
      csprng_randombytes(monomial_seeds[i],
                           SEED_LENGTH_BYTES,
                           &sk_shake_state);
   }
   monomial_t final_mono_secret[NUM_KEYPAIRS-1];
   monomial_t private_Q_transpose[NUM_KEYPAIRS-1], private_Q_inv[NUM_KEYPAIRS-1];
   
   for(int i = 0; i < NUM_KEYPAIRS-1; i++) {
      monomial_mat_seed_expand(&private_Q_inv[i], monomial_seeds[i]);
   }

   monomial_t mono_partial_secret[NUM_KEYPAIRS-1];

   for(int i=0; i<NUM_KEYPAIRS-1; i++){
      partial_monomial_initialize(&final_mono_secret[i]);
      partial_monomial_initialize(&mono_partial_secret[i]);
   }

   int count_mono_coeff[NUM_KEYPAIRS-1]={0};
   int total_count_coeff = 0, count_iteration=0;
   int flag;

   while(total_count_coeff < (NUM_KEYPAIRS-1)){

      count_iteration++;

      flag = sample_binom_p();
      if(flag != 1)
        continue;*/

      //sign_t signature;
      //char message[8] = "Signme!";          /* We do not necessarily need same message */
      //LESS_sign(&sk,message,8,&signature);  /* Fault is induced at line 102-104 of Reference_implementation/lib/seedtree.c */

      /*uint8_t fixed_weight_string[T] = {0};
      expand_digest_to_fixed_weight(fixed_weight_string,signature.digest);

      unsigned char ephem_monomials_seed[SEED_LENGTH_BYTES];
      memcpy(ephem_monomials_seed, signature.seed_storage, SEED_LENGTH_BYTES);
      unsigned char seed_tree[NUM_NODES_OF_SEED_TREE*SEED_LENGTH_BYTES] = {0};

      int t = generate_partial_seed_tree( seed_tree, ephem_monomials_seed,signature.tree_salt);
      unsigned char *ephem_monomial_seeds = seed_tree + SEED_LENGTH_BYTES*(NUM_LEAVES_OF_SEED_TREE-1);
      
      monomial_t Q_tilde;
      normalized_IS_t* V_array = calloc(T, sizeof(normalized_IS_t));
      #ifdef COMPRESS_CMT_COLUMNS
      uint8_t *V_array_compressed = calloc(T*RREF_IS_COLUMNS_PACKEDBYTES, sizeof(uint8_t));
      #endif
      monomial_action_IS_t* Q_bar_actions = calloc(T, sizeof(monomial_action_IS_t));


      rref_generator_mat_t G0_rref;
      generator_SF_seed_expand(&G0_rref, pk.G_0_seed);
      generator_mat_t full_G0;
      generator_rref_expand(&full_G0,&G0_rref);

      int employed_monoms = 0;
      monomial_action_IS_t mono_action;
      for(int i = 0; i < t; i++) {
         int F = fixed_weight_string[i];
         if ( F!= 0){
            //printf("%d\n",F);
            if(count_mono_coeff[F-1]<N) {
                monomial_mat_seed_expand(&Q_tilde, ephem_monomial_seeds+i*SEED_LENGTH_BYTES);
                prepare_digest_input(&V_array[i],&Q_bar_actions[i],&full_G0, &Q_tilde);

                expand_to_monom_action(&mono_action, signature.monom_actions[employed_monoms]);
                find_partial_monomial_update(&mono_partial_secret[F-1], &Q_bar_actions[i], &mono_action);

                // Get F-th public key

                generator_mat_t G_hat;
                expand_to_rref(&G_hat, pk.SF_G[F-1]);

                invertible_mat_t G_hat_J_star, G_0_J, S, G_tmp;

                int k=0;
                for(int x=0; x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            FQ_ELEM tmp = fq_inv(mono_partial_secret[F-1].coefficients[x]);
                            tmp = fq_red((FQ_DOUBLEPREC)tmp * (FQ_DOUBLEPREC)full_G0.values[j][x]);
                            G_0_J.values[j][k] = tmp;
                        }
                        k++;
                    }
                }

                k=0;
                for(int x=0;x<N;x++){
                    if(mono_partial_secret[F-1].permutation[x] != N+1){
                        for(int j=0;j<K;j++){
                            G_hat_J_star.values[j][k] = G_hat.values[j][mono_partial_secret[F-1].permutation[x]];
                        }
                        k++;
                    }
                    
                }

                generator_mat_t G_left, G_right;

                G_tmp = G_0_J;

                matrix_inverse(&G_0_J);

                // Recovering S where G_hat = S * G_0 * Q^{-1}
                mul_invertible_invertible(&S, &G_hat_J_star, &G_0_J);
                matrix_inverse(&S);
                mul_invertible_generator(&G_left, &S, &G_hat);
                
                for(int x=0;x<N;x++)
                {
                    for(FQ_ELEM e = 1; e<Q; e++){
                        int j = compare(&G_left, &full_G0, e, x);
                        //if(j!=N+1) printf("%d %d\n", e, j);
                        if(j!=N+1) {
                            mono_partial_secret[F-1].permutation[x] = j;
                            mono_partial_secret[F-1].coefficients[x] = fq_inv(e);
                        }
                    }
                }

                count_mono_coeff[F-1]=update_count_mono(&mono_partial_secret[F-1]);
                total_count_coeff+=1;
                
            } 

            employed_monoms++;
        
        }
      }
   }

   //printf("The number of iteration is %d\n",count_iteration);
   
   int res;*/
   /* Checking if the recovered secret is same as the actual secret */
    /*for(int i=0; i<NUM_KEYPAIRS-1; i++){
        for(int j=0; j<N; j++){
            if(private_Q_inv[i].coefficients[j]!=mono_partial_secret[i].coefficients[j]
             ||private_Q_inv[i].permutation[j]!=mono_partial_secret[i].permutation[j]){
                    fprintf(stderr,"Recovered secret-key is not same as original secret-key\n");
                res = failure;
             }
        }
    }
    res = success;

    if(res == success)
        *num_sign += count_iteration;
    return res;

}*/
