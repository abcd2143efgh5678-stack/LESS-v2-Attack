Fault simulation for LESS and CROSS
